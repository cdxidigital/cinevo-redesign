# CINEVO — Locked information architecture

**Primary path:** connect library → browse → play  
**Chrome:** one top `AppNav` on `/` and every `/app/*` (nav items swap; no sidebar).  
**Product mark:** keep existing **CINEVO** display mark (not `cinevo` Righteous — that face is for cdxi / fourtee2 / fleshsesh only).

## URL tree

### Public
| Path | Purpose |
|------|---------|
| `/` | Marketing home — CTA: Connect / Log in |
| `/login` | Sign in → `/app/home` |
| `/signup` | Create account → `/app/home` |
| `/connect` | Node install + pair (**replaces** `/node`) |
| `/help` | How connect / browse / play works |
| `/legal/terms` | Terms |
| `/legal/privacy` | Privacy |
| `/share/:token` | Invite accept (**replaces** `/invite/:token`) |
| `/404` `/500` | Error shells |

### App (rooms become real paths)
| Path | Purpose |
|------|---------|
| `/app` | Redirect → `/app/home` |
| `/app/home` | Stage / featured / continue |
| `/app/movies` | Browse movies |
| `/app/shows` | Browse series |
| `/app/library` | Add/manage sources (was sidebar room) |
| `/app/search` | Search |
| `/app/settings` | Prefs + **theme picker** |
| `/app/movies/:id` `/app/shows/:id` | Detail |
| `/app/watch/:id` | Player |
| `/app/core/:tab` | libraries \| sharing \| stewardship \| ai \| operations |

### Kill
- Zustand `room` as source of truth for nav
- Unused `browse` room
- Dual marketing vs app chrome
- Core / share as modal-only (keep modal as presentation if needed, but URL is canonical)

### Nav items
- **Marketing:** Connect · Help · Log in  
- **App:** Home · Movies · Series · Library + Search · Settings  

### Redirects (compat)
- `/node` → `/connect`
- `/invite/:token` → `/share/:token`
