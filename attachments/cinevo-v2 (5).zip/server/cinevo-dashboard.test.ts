import { describe, expect, it } from "vitest";
import { deriveDashboard, getCinevoMood, moveDashboardWidget, sanitizeDashboardWidgets } from "../client/src/lib/cinevo-dashboard";
import { loadCinevoPreferences, sanitizeCinevoPreferences } from "../client/src/lib/cinevo-preferences";
import type { JellyfinMediaItem } from "../client/src/lib/jellyfin-library";

function item(id: string, progress: number | null, isFavorite = false, genres: string[] = ["Drama"]): JellyfinMediaItem {
  return {
    id,
    source: "jellyfin",
    title: `Title ${id}`,
    kind: "movie",
    year: 2025,
    runtime: "110m",
    genre: genres[0] ?? "Drama",
    genres,
    rating: 8.1,
    synopsis: "A private-library test record.",
    primaryImageUrl: null,
    backdropImageUrl: null,
    progress,
    isFavorite,
  };
}

describe("CINEVO reference dashboard helpers", () => {
  it("derives featured, playlist, suggestions, and favourites from real library rows", () => {
    const rows = [item("a", 42), item("b", null, true), item("c", null)];
    const dashboard = deriveDashboard(rows);
    expect(dashboard.featured?.id).toBe("a");
    expect(dashboard.playList.map((row) => row.id)).toEqual(["a"]);
    expect(dashboard.suggestions.map((row) => row.id)).toEqual(["b", "c"]);
    expect(dashboard.myList.map((row) => row.id)).toEqual(["b"]);
  });

  it("maps metadata genres to a stable mood accent", () => {
    expect(getCinevoMood(["Crime", "Thriller"])).toBe("noir");
    expect(getCinevoMood(["Romance"])).toBe("warm");
    expect(getCinevoMood(["Science Fiction"])).toBe("electric");
    expect(getCinevoMood(["Documentary"])).toBe("violet");
  });

  it("moves widgets only within valid bounds and sanitizes unknown persisted values", () => {
    const order = ["playlist", "continue", "suggestions", "my-list"] as const;
    expect(moveDashboardWidget([...order], "continue", "up")).toEqual(["continue", "playlist", "suggestions", "my-list"]);
    expect(moveDashboardWidget([...order], "playlist", "up")).toEqual([...order]);
    expect(sanitizeDashboardWidgets(["suggestions", "unexpected", "suggestions"])).toEqual(["suggestions", "playlist", "continue", "my-list"]);
  });
});

describe("CINEVO local preferences", () => {
  it("falls back safely when persisted preferences are malformed", () => {
    expect(sanitizeCinevoPreferences({ nightMode: false, dashboardWidgets: ["my-list"] })).toMatchObject({
      nightMode: false,
      zenMode: false,
      focusMode: false,
      audioHints: true,
      dashboardWidgets: ["my-list", "playlist", "continue", "suggestions"],
    });
    expect(loadCinevoPreferences({ getItem: () => "not-json" })).toMatchObject({ nightMode: true, focusMode: false });
  });
});
