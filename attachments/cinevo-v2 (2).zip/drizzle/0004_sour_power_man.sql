CREATE TABLE `cinevoNotificationPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`emailEnabled` boolean NOT NULL DEFAULT false,
	`emailProvider` enum('none','resend','sendgrid') NOT NULL DEFAULT 'none',
	`libraryEvents` boolean NOT NULL DEFAULT true,
	`sharingEvents` boolean NOT NULL DEFAULT true,
	`privacyEvents` boolean NOT NULL DEFAULT true,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cinevoNotificationPreferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `cinevoNotificationPreferences_user_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `cinevoNotifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`category` enum('library','sharing','privacy','account') NOT NULL,
	`severity` enum('info','success','attention') NOT NULL DEFAULT 'info',
	`title` varchar(160) NOT NULL,
	`message` varchar(640) NOT NULL,
	`actionHref` varchar(512),
	`readAt` timestamp,
	`dismissedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cinevoNotifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `cinevoNotificationPreferences` ADD CONSTRAINT `cinevoNotificationPreferences_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cinevoNotifications` ADD CONSTRAINT `cinevoNotifications_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;