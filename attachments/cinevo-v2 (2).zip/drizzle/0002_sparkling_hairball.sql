CREATE TABLE `plexConnections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`baseUrl` varchar(2048) NOT NULL,
	`displayName` varchar(255) NOT NULL,
	`machineIdentifier` varchar(255) NOT NULL,
	`encryptedAccessToken` text NOT NULL,
	`clientIdentifier` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `plexConnections_id` PRIMARY KEY(`id`),
	CONSTRAINT `plexConnections_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `plexConnections` ADD CONSTRAINT `plexConnections_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;