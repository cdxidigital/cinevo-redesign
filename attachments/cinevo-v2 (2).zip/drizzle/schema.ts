import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/** A single owner-controlled Jellyfin connection for each CINEVO account. */
export const jellyfinConnections = mysqlTable("jellyfinConnections", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  baseUrl: varchar("baseUrl", { length: 2048 }).notNull(),
  jellyfinUserId: varchar("jellyfinUserId", { length: 128 }).notNull(),
  displayName: varchar("displayName", { length: 255 }).notNull(),
  encryptedAccessToken: text("encryptedAccessToken").notNull(),
  deviceId: varchar("deviceId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("jellyfinConnections_userId_unique").on(table.userId)]);

export type JellyfinConnection = typeof jellyfinConnections.$inferSelect;
export type InsertJellyfinConnection = typeof jellyfinConnections.$inferInsert;

/** A single owner-controlled Plex Media Server connection for each CINEVO account. */
export const plexConnections = mysqlTable("plexConnections", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  baseUrl: varchar("baseUrl", { length: 2048 }).notNull(),
  displayName: varchar("displayName", { length: 255 }).notNull(),
  machineIdentifier: varchar("machineIdentifier", { length: 255 }).notNull(),
  encryptedAccessToken: text("encryptedAccessToken").notNull(),
  clientIdentifier: varchar("clientIdentifier", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("plexConnections_userId_unique").on(table.userId)]);

export type PlexConnection = typeof plexConnections.$inferSelect;
export type InsertPlexConnection = typeof plexConnections.$inferInsert;

/** Owner-selected library sections indexed privately from a connected media server. */
export const cinevoLibraries = mysqlTable("cinevoLibraries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  provider: mysqlEnum("provider", ["plex", "jellyfin"]).notNull(),
  externalId: varchar("externalId", { length: 255 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  kind: mysqlEnum("kind", ["movie", "series", "music", "photo", "mixed"]).default("mixed").notNull(),
  isSelected: boolean("isSelected").default(false).notNull(),
  scanState: mysqlEnum("scanState", ["idle", "requested", "scanning", "complete", "issue"]).default("idle").notNull(),
  itemCount: int("itemCount").default(0).notNull(),
  lastScanAt: timestamp("lastScanAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("cinevoLibraries_owner_source_unique").on(table.userId, table.provider, table.externalId)]);

export type CinevoLibrary = typeof cinevoLibraries.$inferSelect;
export type InsertCinevoLibrary = typeof cinevoLibraries.$inferInsert;

/** Invitation records grant opt-in, scoped access only to explicitly selected owner libraries. */
export const cinevoShareInvites = mysqlTable("cinevoShareInvites", {
  id: int("id").autoincrement().primaryKey(),
  ownerUserId: int("ownerUserId").notNull().references(() => users.id),
  inviteToken: varchar("inviteToken", { length: 96 }).notNull(),
  recipientLabel: varchar("recipientLabel", { length: 255 }).notNull(),
  libraryIdsJson: text("libraryIdsJson").notNull(),
  status: mysqlEnum("status", ["pending", "active", "paused", "revoked", "expired"]).default("pending").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("cinevoShareInvites_token_unique").on(table.inviteToken)]);

export type CinevoShareInvite = typeof cinevoShareInvites.$inferSelect;
export type InsertCinevoShareInvite = typeof cinevoShareInvites.$inferInsert;

/** Owner-visible, non-consumption stewardship milestones for personal library care. */
export const cinevoStewardshipEvents = mysqlTable("cinevoStewardshipEvents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  type: mysqlEnum("type", ["library_selected", "library_scanned", "invite_created", "invite_revoked", "privacy_reviewed", "ai_enabled"]).notNull(),
  points: int("points").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CinevoStewardshipEvent = typeof cinevoStewardshipEvents.$inferSelect;
export type InsertCinevoStewardshipEvent = typeof cinevoStewardshipEvents.$inferInsert;

/** Explicit, reversible owner consent for AI assistance on selected metadata only. */
export const cinevoAiPreferences = mysqlTable("cinevoAiPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  isEnabled: boolean("isEnabled").default(false).notNull(),
  scope: mysqlEnum("scope", ["active_library", "selected_libraries"]).default("active_library").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("cinevoAiPreferences_user_unique").on(table.userId)]);

export type CinevoAiPreference = typeof cinevoAiPreferences.$inferSelect;
export type InsertCinevoAiPreference = typeof cinevoAiPreferences.$inferInsert;

/** Private, owner-scoped activity notices shown only inside the authenticated CINEVO experience. */
export const cinevoNotifications = mysqlTable("cinevoNotifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  category: mysqlEnum("category", ["library", "sharing", "privacy", "account"]).notNull(),
  severity: mysqlEnum("severity", ["info", "success", "attention"]).default("info").notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  message: varchar("message", { length: 640 }).notNull(),
  actionHref: varchar("actionHref", { length: 512 }),
  emailDeliveryState: mysqlEnum("emailDeliveryState", ["not_requested", "disabled", "sent", "failed"]).default("not_requested").notNull(),
  readAt: timestamp("readAt"),
  dismissedAt: timestamp("dismissedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CinevoNotification = typeof cinevoNotifications.$inferSelect;
export type InsertCinevoNotification = typeof cinevoNotifications.$inferInsert;

/** Disabled-by-default email-alert preferences; provider credentials always remain server-side. */
export const cinevoNotificationPreferences = mysqlTable("cinevoNotificationPreferences", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  emailEnabled: boolean("emailEnabled").default(false).notNull(),
  provider: mysqlEnum("emailProvider", ["none", "resend", "sendgrid"]).default("none").notNull(),
  libraryEvents: boolean("libraryEvents").default(true).notNull(),
  sharingEvents: boolean("sharingEvents").default(true).notNull(),
  privacyEvents: boolean("privacyEvents").default(true).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("cinevoNotificationPreferences_user_unique").on(table.userId)]);

export type CinevoNotificationPreference = typeof cinevoNotificationPreferences.$inferSelect;
export type InsertCinevoNotificationPreference = typeof cinevoNotificationPreferences.$inferInsert;
