CREATE TABLE `jellyfinConnections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`baseUrl` varchar(2048) NOT NULL,
	`jellyfinUserId` varchar(128) NOT NULL,
	`displayName` varchar(255) NOT NULL,
	`encryptedAccessToken` text NOT NULL,
	`deviceId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `jellyfinConnections_id` PRIMARY KEY(`id`),
	CONSTRAINT `jellyfinConnections_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `jellyfinConnections` ADD CONSTRAINT `jellyfinConnections_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;