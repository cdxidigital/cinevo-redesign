CREATE TABLE `cinevoAiPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`isEnabled` boolean NOT NULL DEFAULT false,
	`scope` enum('active_library','selected_libraries') NOT NULL DEFAULT 'active_library',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cinevoAiPreferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `cinevoAiPreferences_user_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `cinevoLibraries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`provider` enum('plex','jellyfin') NOT NULL,
	`externalId` varchar(255) NOT NULL,
	`name` varchar(255) NOT NULL,
	`kind` enum('movie','series','music','photo','mixed') NOT NULL DEFAULT 'mixed',
	`isSelected` boolean NOT NULL DEFAULT false,
	`scanState` enum('idle','requested','scanning','complete','issue') NOT NULL DEFAULT 'idle',
	`itemCount` int NOT NULL DEFAULT 0,
	`lastScanAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cinevoLibraries_id` PRIMARY KEY(`id`),
	CONSTRAINT `cinevoLibraries_owner_source_unique` UNIQUE(`userId`,`provider`,`externalId`)
);
--> statement-breakpoint
CREATE TABLE `cinevoShareInvites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerUserId` int NOT NULL,
	`inviteToken` varchar(96) NOT NULL,
	`recipientLabel` varchar(255) NOT NULL,
	`libraryIdsJson` text NOT NULL,
	`status` enum('pending','active','paused','revoked','expired') NOT NULL DEFAULT 'pending',
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cinevoShareInvites_id` PRIMARY KEY(`id`),
	CONSTRAINT `cinevoShareInvites_token_unique` UNIQUE(`inviteToken`)
);
--> statement-breakpoint
CREATE TABLE `cinevoStewardshipEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('library_selected','library_scanned','invite_created','invite_revoked','privacy_reviewed','ai_enabled') NOT NULL,
	`points` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cinevoStewardshipEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `cinevoAiPreferences` ADD CONSTRAINT `cinevoAiPreferences_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cinevoLibraries` ADD CONSTRAINT `cinevoLibraries_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cinevoShareInvites` ADD CONSTRAINT `cinevoShareInvites_ownerUserId_users_id_fk` FOREIGN KEY (`ownerUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cinevoStewardshipEvents` ADD CONSTRAINT `cinevoStewardshipEvents_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;