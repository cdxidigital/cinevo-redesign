import { describe, expect, it } from "vitest";
import { isSearchDismissKey, nextAudioTrackIndex, toggleLocalList } from "../client/src/lib/cinevo-state";

describe("CINEVO prototype interaction utilities", () => {
  it("adds and removes a title from the local My List state", () => {
    expect(toggleLocalList(["velaris"], "after-light")).toEqual(["velaris", "after-light"]);
    expect(toggleLocalList(["velaris", "after-light"], "after-light")).toEqual(["velaris"]);
  });

  it("uses Escape as the search-dismiss shortcut", () => {
    expect(isSearchDismissKey("Escape")).toBe(true);
    expect(isSearchDismissKey("Enter")).toBe(false);
  });

  it("cycles the available player audio tracks", () => {
    expect(nextAudioTrackIndex(0, 3)).toBe(1);
    expect(nextAudioTrackIndex(2, 3)).toBe(0);
  });
});

