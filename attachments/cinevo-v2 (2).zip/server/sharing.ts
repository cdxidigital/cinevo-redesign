import { randomBytes } from "crypto";
import * as db from "./db";

const statuses = ["pending", "active", "paused", "revoked", "expired"] as const;
export type ShareStatus = (typeof statuses)[number];

export async function createPrivateInvite(input: { ownerUserId: number; recipientLabel: string; libraryIds: number[]; expiresInDays: number }) {
  const recipientLabel = input.recipientLabel.trim();
  if (!recipientLabel) throw new Error("Give this invitation a recipient name");
  if (!input.libraryIds.length) throw new Error("Choose at least one library to share");
  if (input.expiresInDays < 1 || input.expiresInDays > 30) throw new Error("Choose an invitation expiry between 1 and 30 days");
  const selected = (await db.listCinevoLibraries(input.ownerUserId)).filter((library) => library.isSelected);
  if (input.libraryIds.some((id) => !selected.some((library) => library.id === id))) throw new Error("Only selected private libraries can be shared");
  const inviteToken = randomBytes(24).toString("base64url");
  const expiresAt = new Date(Date.now() + input.expiresInDays * 86_400_000);
  const invite = await db.createCinevoShareInvite({ ownerUserId: input.ownerUserId, inviteToken, recipientLabel, libraryIdsJson: JSON.stringify(input.libraryIds), expiresAt, status: "pending" });
  await db.recordCinevoStewardshipEvent({ userId: input.ownerUserId, type: "invite_created", points: 10 });
  return { ...invite, shareCode: inviteToken };
}

export async function listPrivateInvites(ownerUserId: number) {
  const invites = await db.listCinevoShareInvites(ownerUserId);
  const now = Date.now();
  return Promise.all(invites.map(async (invite) => {
    if (invite.status !== "revoked" && invite.status !== "expired" && invite.expiresAt.getTime() <= now) {
      await db.updateCinevoShareInvite(ownerUserId, invite.id, "expired");
      return { ...invite, status: "expired" as const };
    }
    return invite;
  }));
}

export async function changePrivateInviteStatus(ownerUserId: number, inviteId: number, status: ShareStatus) {
  await db.updateCinevoShareInvite(ownerUserId, inviteId, status);
  if (status === "revoked") await db.recordCinevoStewardshipEvent({ userId: ownerUserId, type: "invite_revoked", points: 3 });
  return listPrivateInvites(ownerUserId);
}

export async function getPublicInvite(inviteToken: string) {
  const invite = await db.getCinevoShareInviteByToken(inviteToken);
  if (!invite) throw new Error("This private invitation is not available");
  const isExpired = invite.expiresAt.getTime() <= Date.now();
  const status = isExpired && invite.status !== "revoked" ? "expired" : invite.status;
  if (status === "expired" && invite.status !== "expired") await db.updateCinevoShareInvite(invite.ownerUserId, invite.id, "expired");
  return { status, expiresAt: invite.expiresAt, libraryCount: JSON.parse(invite.libraryIdsJson).length };
}
