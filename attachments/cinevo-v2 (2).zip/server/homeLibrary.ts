import * as db from "./db";
import { getJellyfinLibraryItemsForSections, getJellyfinLibrarySections, requestJellyfinLibraryScan } from "./jellyfin";
import { getPlexLibraryItemsForSections, getPlexLibrarySections, requestPlexLibraryScan } from "./plex";

export async function discoverHomeLibraries(userId: number) {
  const pending: Parameters<typeof db.saveCinevoLibraries>[0] = [];
  if (await db.getPlexConnectionByUserId(userId)) {
    const sections = await getPlexLibrarySections(userId);
    pending.push(...sections.map((section) => ({ userId, provider: "plex" as const, ...section })));
  }
  if (await db.getJellyfinConnectionByUserId(userId)) {
    const sections = await getJellyfinLibrarySections(userId);
    pending.push(...sections.map((section) => ({ userId, provider: "jellyfin" as const, ...section })));
  }
  if (pending.length) await db.saveCinevoLibraries(pending);
  return db.listCinevoLibraries(userId);
}

export async function selectHomeLibraries(userId: number, libraryIds: number[]) {
  const owned = await db.listCinevoLibraries(userId);
  if (libraryIds.some((libraryId) => !owned.some((library) => library.id === libraryId))) throw new Error("Choose libraries from your own connected servers");
  const libraries = await db.setSelectedCinevoLibraries(userId, libraryIds);
  if (libraryIds.length) await db.recordCinevoStewardshipEvent({ userId, type: "library_selected", points: 5 });
  return libraries;
}

export async function scanHomeLibrary(userId: number, libraryId: number) {
  const library = (await db.listCinevoLibraries(userId)).find((entry) => entry.id === libraryId && entry.isSelected);
  if (!library) throw new Error("Select this library before requesting a private scan");
  await db.updateCinevoLibraryScan(userId, libraryId, "scanning");
  try {
    if (library.provider === "plex") {
      await requestPlexLibraryScan(userId, library.externalId);
      const items = await getPlexLibraryItemsForSections(userId, [library.externalId]);
      await db.updateCinevoLibraryScan(userId, libraryId, "complete", items.length);
    } else {
      await requestJellyfinLibraryScan(userId, library.externalId);
      const items = await getJellyfinLibraryItemsForSections(userId, [library.externalId]);
      await db.updateCinevoLibraryScan(userId, libraryId, "complete", items.length);
    }
    await db.recordCinevoStewardshipEvent({ userId, type: "library_scanned", points: 8 });
    return (await db.listCinevoLibraries(userId)).find((entry) => entry.id === libraryId);
  } catch (error) {
    await db.updateCinevoLibraryScan(userId, libraryId, "issue");
    throw error;
  }
}

export async function selectedHomeLibraryItems(userId: number, allowedLibraryIds?: number[]) {
  const selected = (await db.listCinevoLibraries(userId)).filter((library) => library.isSelected && (!allowedLibraryIds || allowedLibraryIds.includes(library.id)));
  const plexIds = selected.filter((library) => library.provider === "plex").map((library) => library.externalId);
  const jellyfinIds = selected.filter((library) => library.provider === "jellyfin").map((library) => library.externalId);
  const [plexItems, jellyfinItems] = await Promise.all([
    plexIds.length ? getPlexLibraryItemsForSections(userId, plexIds) : Promise.resolve([]),
    jellyfinIds.length ? getJellyfinLibraryItemsForSections(userId, jellyfinIds) : Promise.resolve([]),
  ]);
  return [...plexItems, ...jellyfinItems].sort((a, b) => (b.addedAt || "").localeCompare(a.addedAt || ""));
}

export async function selectedHomeLibraryMetadata(userId: number, limit = 80, allowedLibraryIds?: number[]) {
  return (await selectedHomeLibraryItems(userId, allowedLibraryIds)).slice(0, limit).map((item) => ({ title: item.title, kind: item.kind, year: item.year, genres: item.genres, rating: item.rating }));
}

export async function getHomeLibraryOverview(userId: number) {
  const libraries = await db.listCinevoLibraries(userId);
  const events = await db.getCinevoStewardship(userId);
  const points = events.reduce((total, event) => total + event.points, 0);
  return { libraries, stewardship: { points, events: events.slice(0, 8) } };
}
