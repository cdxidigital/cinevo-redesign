import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { connectJellyfinLibrary, disconnectJellyfinLibrary, getJellyfinConnectionStatus, getJellyfinLibrary, setJellyfinFavorite } from "./jellyfin";
import { connectPlexLibrary, disconnectPlexLibrary, getPlexConnectionStatus, getPlexLibrary } from "./plex";
import { askLibraryConcierge, getAiConsent, setAiConsent } from "./aiConcierge";
import { discoverHomeLibraries, getHomeLibraryOverview, scanHomeLibrary, selectHomeLibraries, selectedHomeLibraryItems } from "./homeLibrary";
import { changePrivateInviteStatus, createPrivateInvite, getPublicInvite, listPrivateInvites } from "./sharing";
import { emitCinevoNotification, getNotificationCentre, notificationActions, updateNotificationPreference } from "./notifications";
import { buildOwnerExport, getFutureReadinessOverview } from "./futureReadiness";

function jellyfinError(error: unknown): never {
  const message = error instanceof Error ? error.message : "CINEVO could not complete that Jellyfin request";
  throw new TRPCError({ code: "BAD_REQUEST", message });
}

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  jellyfin: router({
    status: protectedProcedure.query(async ({ ctx }) => getJellyfinConnectionStatus(ctx.user.id)),
    connect: protectedProcedure.input(z.object({
      baseUrl: z.string().min(1).max(2048),
      username: z.string().min(1).max(255),
      password: z.string().min(1).max(1024),
    })).mutation(async ({ ctx, input }) => {
      try {
        const result = await connectJellyfinLibrary({ userId: ctx.user.id, ...input });
        await emitCinevoNotification(ctx.user.id, { category: "library", severity: "success", title: "Jellyfin connected", message: "Your Jellyfin server is ready for private library selection.", actionHref: "/app?core=libraries" });
        return result;
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    disconnect: protectedProcedure.mutation(async ({ ctx }) => disconnectJellyfinLibrary(ctx.user.id)),
    library: protectedProcedure.query(async ({ ctx }) => {
      try {
        return await getJellyfinLibrary(ctx.user.id);
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    setFavorite: protectedProcedure.input(z.object({
      id: z.string().min(1).max(128),
      isFavorite: z.boolean(),
    })).mutation(async ({ ctx, input }) => {
      try {
        return await setJellyfinFavorite(ctx.user.id, input.id, input.isFavorite);
      } catch (error) {
        return jellyfinError(error);
      }
    }),
  }),
  plex: router({
    status: protectedProcedure.query(async ({ ctx }) => getPlexConnectionStatus(ctx.user.id)),
    connect: protectedProcedure.input(z.object({
      baseUrl: z.string().min(1).max(2048),
      token: z.string().min(1).max(2048),
    })).mutation(async ({ ctx, input }) => {
      try {
        const result = await connectPlexLibrary({ userId: ctx.user.id, ...input });
        await emitCinevoNotification(ctx.user.id, { category: "library", severity: "success", title: "Plex connected", message: "Your Plex server is ready for private library selection.", actionHref: "/app?core=libraries" });
        return result;
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    disconnect: protectedProcedure.mutation(async ({ ctx }) => disconnectPlexLibrary(ctx.user.id)),
    library: protectedProcedure.query(async ({ ctx }) => {
      try {
        return await getPlexLibrary(ctx.user.id);
      } catch (error) {
        return jellyfinError(error);
      }
    }),
  }),
  homeLibrary: router({
    overview: protectedProcedure.query(async ({ ctx }) => getHomeLibraryOverview(ctx.user.id)),
    media: protectedProcedure.query(async ({ ctx }) => {
      try {
        return await selectedHomeLibraryItems(ctx.user.id);
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    discover: protectedProcedure.mutation(async ({ ctx }) => {
      try {
        return await discoverHomeLibraries(ctx.user.id);
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    select: protectedProcedure.input(z.object({ libraryIds: z.array(z.number().int().positive()).max(50) })).mutation(async ({ ctx, input }) => {
      try {
        const result = await selectHomeLibraries(ctx.user.id, input.libraryIds);
        await emitCinevoNotification(ctx.user.id, { category: "library", severity: "success", title: "Library selection updated", message: `${input.libraryIds.length} home ${input.libraryIds.length === 1 ? "library is" : "libraries are"} now selected for CINEVO.`, actionHref: "/app?core=libraries" });
        return result;
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    scan: protectedProcedure.input(z.object({ libraryId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      try {
        const result = await scanHomeLibrary(ctx.user.id, input.libraryId);
        await emitCinevoNotification(ctx.user.id, { category: "library", severity: "info", title: "Library scan requested", message: "Your connected media server accepted the private library scan request.", actionHref: "/app?core=libraries" });
        return result;
      } catch (error) {
        return jellyfinError(error);
      }
    }),
  }),
  sharing: router({
    list: protectedProcedure.query(async ({ ctx }) => listPrivateInvites(ctx.user.id)),
    publicInvite: publicProcedure.input(z.object({ token: z.string().min(16).max(96) })).query(async ({ input }) => {
      try {
        return await getPublicInvite(input.token);
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    create: protectedProcedure.input(z.object({
      recipientLabel: z.string().trim().min(1).max(255),
      libraryIds: z.array(z.number().int().positive()).min(1).max(50),
      expiresInDays: z.number().int().min(1).max(30),
    })).mutation(async ({ ctx, input }) => {
      try {
        const result = await createPrivateInvite({ ownerUserId: ctx.user.id, ...input });
        await emitCinevoNotification(ctx.user.id, { category: "sharing", severity: "success", title: "Private invitation created", message: `A time-bound invitation was created for ${input.libraryIds.length} selected ${input.libraryIds.length === 1 ? "library" : "libraries"}.`, actionHref: "/app?core=sharing" });
        return result;
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    updateStatus: protectedProcedure.input(z.object({
      inviteId: z.number().int().positive(),
      status: z.enum(["pending", "active", "paused", "revoked", "expired"]),
    })).mutation(async ({ ctx, input }) => {
      try {
        const result = await changePrivateInviteStatus(ctx.user.id, input.inviteId, input.status);
        await emitCinevoNotification(ctx.user.id, { category: "sharing", severity: input.status === "revoked" ? "attention" : "info", title: `Invitation ${input.status}`, message: "A private sharing invitation changed state. No library credentials were disclosed.", actionHref: "/app?core=sharing" });
        return result;
      } catch (error) {
        return jellyfinError(error);
      }
    }),
  }),
  ai: router({
    consent: protectedProcedure.query(async ({ ctx }) => getAiConsent(ctx.user.id)),
    setConsent: protectedProcedure.input(z.object({ isEnabled: z.boolean(), scope: z.enum(["active_library", "selected_libraries"]) })).mutation(async ({ ctx, input }) => {
      try {
        const result = await setAiConsent(ctx.user.id, input.isEnabled, input.scope);
        await emitCinevoNotification(ctx.user.id, { category: "privacy", severity: "info", title: input.isEnabled ? "AI assistance enabled" : "AI assistance disabled", message: input.isEnabled ? "CINEVO may use only the library metadata scope you selected." : "CINEVO AI metadata access is now disabled.", actionHref: "/app?core=ai" });
        return result;
      } catch (error) {
        return jellyfinError(error);
      }
    }),
    ask: protectedProcedure.input(z.object({ question: z.string().trim().min(1).max(600), activeLibraryId: z.number().int().positive().optional() })).mutation(async ({ ctx, input }) => {
      try {
        return await askLibraryConcierge(ctx.user.id, input.question, input.activeLibraryId);
      } catch (error) {
        return jellyfinError(error);
      }
    }),
  }),
  notifications: router({
    centre: protectedProcedure.query(async ({ ctx }) => getNotificationCentre(ctx.user.id)),
    markRead: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      await notificationActions.markRead(ctx.user.id, input.id);
      return { success: true } as const;
    }),
    dismiss: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      await notificationActions.dismiss(ctx.user.id, input.id);
      return { success: true } as const;
    }),
    clearAll: protectedProcedure.mutation(async ({ ctx }) => {
      await notificationActions.clearAll(ctx.user.id);
      return { success: true } as const;
    }),
    savePreference: protectedProcedure.input(z.object({
      emailEnabled: z.boolean(),
      provider: z.enum(["none", "resend", "sendgrid"]),
      libraryEvents: z.boolean(),
      sharingEvents: z.boolean(),
      privacyEvents: z.boolean(),
    })).mutation(async ({ ctx, input }) => updateNotificationPreference(ctx.user.id, input)),
  }),
  future: router({
    overview: protectedProcedure.query(async ({ ctx }) => getFutureReadinessOverview(ctx.user.id)),
    export: protectedProcedure.mutation(async ({ ctx }) => buildOwnerExport(ctx.user.id)),
  }),
});

export type AppRouter = typeof appRouter;
