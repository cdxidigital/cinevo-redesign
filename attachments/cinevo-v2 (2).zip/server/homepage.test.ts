import { describe, expect, it } from "vitest";
import { homeHighlights, homeNav } from "../client/src/lib/homepage-content";

describe("CINEVO homepage content model", () => {
  it("keeps the public navigation focused on product pathways", () => {
    expect(homeNav.map((item) => item.label)).toEqual(["Home", "Your library", "Sharing", "CINEVO Core"]);
    expect(homeNav.every((item) => item.href.startsWith("/") || item.href.startsWith("#"))).toBe(true);
  });

  it("uses four privacy-first product pathways without unsupported product claims", () => {
    expect(homeHighlights).toHaveLength(4);
    expect(homeHighlights.map((item) => item.eyebrow)).toEqual(["PRIVATE LIBRARIES", "FRIEND SHARING", "CINEVO CORE", "CONSENT-LED AI"]);
    expect(homeHighlights.join(" ").toLowerCase()).not.toContain("zero latency");
  });
});
