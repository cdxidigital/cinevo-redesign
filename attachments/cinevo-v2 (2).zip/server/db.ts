import { and, desc, eq, inArray, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { CinevoAiPreference, CinevoLibrary, CinevoNotification, CinevoNotificationPreference, CinevoShareInvite, CinevoStewardshipEvent, InsertCinevoAiPreference, InsertCinevoLibrary, InsertCinevoNotification, InsertCinevoNotificationPreference, InsertCinevoShareInvite, InsertCinevoStewardshipEvent, InsertJellyfinConnection, InsertPlexConnection, InsertUser, cinevoAiPreferences, cinevoLibraries, cinevoNotificationPreferences, cinevoNotifications, cinevoShareInvites, cinevoStewardshipEvents, jellyfinConnections, plexConnections, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getJellyfinConnectionByUserId(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  const result = await db.select().from(jellyfinConnections).where(eq(jellyfinConnections.userId, userId)).limit(1);
  return result[0];
}

export async function saveJellyfinConnection(connection: InsertJellyfinConnection) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.insert(jellyfinConnections).values(connection).onDuplicateKeyUpdate({
    set: {
      baseUrl: connection.baseUrl,
      jellyfinUserId: connection.jellyfinUserId,
      displayName: connection.displayName,
      encryptedAccessToken: connection.encryptedAccessToken,
      deviceId: connection.deviceId,
    },
  });
}

export async function deleteJellyfinConnectionByUserId(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.delete(jellyfinConnections).where(eq(jellyfinConnections.userId, userId));
}

export async function getPlexConnectionByUserId(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  const result = await db.select().from(plexConnections).where(eq(plexConnections.userId, userId)).limit(1);
  return result[0];
}

export async function savePlexConnection(connection: InsertPlexConnection) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.insert(plexConnections).values(connection).onDuplicateKeyUpdate({
    set: {
      baseUrl: connection.baseUrl,
      displayName: connection.displayName,
      machineIdentifier: connection.machineIdentifier,
      encryptedAccessToken: connection.encryptedAccessToken,
      clientIdentifier: connection.clientIdentifier,
    },
  });
}

export async function deletePlexConnectionByUserId(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable");
  await db.delete(plexConnections).where(eq(plexConnections.userId, userId));
}

export async function listCinevoLibraries(userId: number): Promise<CinevoLibrary[]> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  return database.select().from(cinevoLibraries).where(eq(cinevoLibraries.userId, userId));
}

export async function saveCinevoLibraries(libraries: InsertCinevoLibrary[]) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  for (const library of libraries) {
    await database.insert(cinevoLibraries).values(library).onDuplicateKeyUpdate({
      set: { name: library.name, kind: library.kind, itemCount: library.itemCount },
    });
  }
}

export async function setSelectedCinevoLibraries(userId: number, libraryIds: number[]) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.update(cinevoLibraries).set({ isSelected: false }).where(eq(cinevoLibraries.userId, userId));
  if (libraryIds.length) {
    await database.update(cinevoLibraries).set({ isSelected: true, scanState: "requested" }).where(and(eq(cinevoLibraries.userId, userId), inArray(cinevoLibraries.id, libraryIds)));
  }
  return listCinevoLibraries(userId);
}

export async function updateCinevoLibraryScan(userId: number, libraryId: number, state: "idle" | "requested" | "scanning" | "complete" | "issue", itemCount?: number) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  const update: Partial<InsertCinevoLibrary> = { scanState: state };
  if (state === "complete") update.lastScanAt = new Date();
  if (typeof itemCount === "number") update.itemCount = itemCount;
  await database.update(cinevoLibraries).set(update).where(and(eq(cinevoLibraries.userId, userId), eq(cinevoLibraries.id, libraryId)));
}

export async function createCinevoShareInvite(invite: InsertCinevoShareInvite): Promise<CinevoShareInvite> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.insert(cinevoShareInvites).values(invite);
  const result = await database.select().from(cinevoShareInvites).where(eq(cinevoShareInvites.inviteToken, invite.inviteToken)).limit(1);
  if (!result[0]) throw new Error("CINEVO could not create that invitation");
  return result[0];
}

export async function listCinevoShareInvites(ownerUserId: number): Promise<CinevoShareInvite[]> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  return database.select().from(cinevoShareInvites).where(eq(cinevoShareInvites.ownerUserId, ownerUserId)).orderBy(desc(cinevoShareInvites.createdAt));
}

export async function getCinevoShareInviteByToken(inviteToken: string): Promise<CinevoShareInvite | undefined> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  const result = await database.select().from(cinevoShareInvites).where(eq(cinevoShareInvites.inviteToken, inviteToken)).limit(1);
  return result[0];
}

export async function updateCinevoShareInvite(ownerUserId: number, inviteId: number, status: "pending" | "active" | "paused" | "revoked" | "expired") {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.update(cinevoShareInvites).set({ status }).where(and(eq(cinevoShareInvites.ownerUserId, ownerUserId), eq(cinevoShareInvites.id, inviteId)));
}

export async function recordCinevoStewardshipEvent(event: InsertCinevoStewardshipEvent): Promise<CinevoStewardshipEvent> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  const result = await database.insert(cinevoStewardshipEvents).values(event);
  const id = Number(result[0].insertId);
  const rows = await database.select().from(cinevoStewardshipEvents).where(eq(cinevoStewardshipEvents.id, id)).limit(1);
  if (!rows[0]) throw new Error("CINEVO could not record the stewardship event");
  return rows[0];
}

export async function getCinevoStewardship(userId: number): Promise<CinevoStewardshipEvent[]> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  return database.select().from(cinevoStewardshipEvents).where(eq(cinevoStewardshipEvents.userId, userId)).orderBy(desc(cinevoStewardshipEvents.createdAt));
}

export async function getCinevoAiPreference(userId: number): Promise<CinevoAiPreference | undefined> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  const result = await database.select().from(cinevoAiPreferences).where(eq(cinevoAiPreferences.userId, userId)).limit(1);
  return result[0];
}

export async function saveCinevoAiPreference(preference: InsertCinevoAiPreference) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.insert(cinevoAiPreferences).values(preference).onDuplicateKeyUpdate({ set: { isEnabled: preference.isEnabled, scope: preference.scope } });
  return getCinevoAiPreference(preference.userId);
}

export async function createCinevoNotification(notification: InsertCinevoNotification): Promise<CinevoNotification> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  const result = await database.insert(cinevoNotifications).values(notification);
  const rows = await database.select().from(cinevoNotifications).where(eq(cinevoNotifications.id, Number(result[0].insertId))).limit(1);
  if (!rows[0]) throw new Error("CINEVO could not create the notification");
  return rows[0];
}

export async function listCinevoNotifications(userId: number): Promise<CinevoNotification[]> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  return database.select().from(cinevoNotifications).where(and(eq(cinevoNotifications.userId, userId), isNull(cinevoNotifications.dismissedAt))).orderBy(desc(cinevoNotifications.createdAt));
}

export async function markCinevoNotificationRead(userId: number, notificationId: number) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.update(cinevoNotifications).set({ readAt: new Date() }).where(and(eq(cinevoNotifications.userId, userId), eq(cinevoNotifications.id, notificationId)));
}

export async function dismissCinevoNotification(userId: number, notificationId: number) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.update(cinevoNotifications).set({ dismissedAt: new Date() }).where(and(eq(cinevoNotifications.userId, userId), eq(cinevoNotifications.id, notificationId)));
}

export async function clearCinevoNotifications(userId: number) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.update(cinevoNotifications).set({ dismissedAt: new Date() }).where(eq(cinevoNotifications.userId, userId));
}

export async function updateCinevoNotificationDeliveryState(userId: number, notificationId: number, emailDeliveryState: "not_requested" | "disabled" | "sent" | "failed") {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.update(cinevoNotifications).set({ emailDeliveryState }).where(and(eq(cinevoNotifications.userId, userId), eq(cinevoNotifications.id, notificationId)));
}

export async function getCinevoNotificationPreference(userId: number): Promise<CinevoNotificationPreference | undefined> {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  const rows = await database.select().from(cinevoNotificationPreferences).where(eq(cinevoNotificationPreferences.userId, userId)).limit(1);
  return rows[0];
}

export async function saveCinevoNotificationPreference(preference: InsertCinevoNotificationPreference) {
  const database = await getDb();
  if (!database) throw new Error("Database is unavailable");
  await database.insert(cinevoNotificationPreferences).values(preference).onDuplicateKeyUpdate({ set: {
    emailEnabled: preference.emailEnabled,
    provider: preference.provider,
    libraryEvents: preference.libraryEvents,
    sharingEvents: preference.sharingEvents,
    privacyEvents: preference.privacyEvents,
  } });
  return getCinevoNotificationPreference(preference.userId);
}
