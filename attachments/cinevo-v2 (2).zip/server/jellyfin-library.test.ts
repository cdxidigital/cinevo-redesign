import { describe, expect, it } from "vitest";
import { filterLibraryItems, initialLibraryFilters, type JellyfinMediaItem } from "../client/src/lib/jellyfin-library";

const items: JellyfinMediaItem[] = [
  { id: "1", source: "jellyfin", title: "North", kind: "movie", year: "2026", runtime: "2h 01m", genre: "Drama", genres: ["Drama"], synopsis: "Snowbound investigation", cast: ["Mara Vale"], rating: 8.4, addedAt: null, progress: null, isFavorite: false, primaryImageUrl: null, backdropImageUrl: null },
  { id: "2", source: "jellyfin", title: "Echo", kind: "series", year: "2024", runtime: "—", genre: "Science fiction", genres: ["Science fiction"], synopsis: "Signals from the deep", cast: ["Ilan Reed"], rating: 7.1, addedAt: null, progress: null, isFavorite: false, primaryImageUrl: null, backdropImageUrl: null },
  { id: "3", source: "plex", title: "Signal Line", kind: "movie", year: "2026", runtime: "2h 00m", genre: "Science fiction", genres: ["Science fiction", "Thriller"], synopsis: "A signal emerges beyond the network", cast: ["Rin Calder"], rating: 8.3, addedAt: null, progress: 50, isFavorite: false, primaryImageUrl: null, backdropImageUrl: null },
];

describe("CINEVO live-library search filters", () => {
  it("filters a connected library by genre, year, and rating", () => {
    expect(filterLibraryItems(items, "", { genre: "Drama", year: "2026", minRating: 8 })).toEqual([items[0]]);
  });

  it("searches titles and synopses while preserving the selected media type", () => {
    expect(filterLibraryItems(items, "signals", initialLibraryFilters, "series")).toEqual([items[1]]);
  });

  it("filters Plex-sourced titles through the same genre, year, rating, and text controls", () => {
    expect(filterLibraryItems(items, "network", { genre: "Science fiction", year: "2026", minRating: 8 }, "movie")).toEqual([items[2]]);
  });
});
