import { describe, expect, it } from "vitest";
import { normalizePlexItem } from "./plex";

describe("Plex library normalization", () => {
  it("maps Plex movie metadata into CINEVO’s shared multi-library model", () => {
    const item = normalizePlexItem({
      ratingKey: "plex-42",
      title: "Signal Line",
      type: "movie",
      year: 2026,
      duration: 7_200_000,
      summary: "A signal emerges beyond the network.",
      Genre: [{ tag: "Science fiction" }, { tag: "Thriller" }],
      Role: [{ tag: "Rin Calder" }],
      rating: 8.3,
      addedAt: 1_700_000_000,
      viewOffset: 3_600_000,
      thumb: "/library/metadata/plex-42/thumb",
      art: "/library/metadata/plex-42/art",
    });

    expect(item).toMatchObject({
      id: "plex-42",
      source: "plex",
      kind: "movie",
      runtime: "2h 00m",
      genre: "Science fiction",
      rating: 8.3,
      progress: 50,
      primaryImageUrl: "/api/plex/image/plex-42?type=Primary",
      backdropImageUrl: "/api/plex/image/plex-42?type=Backdrop",
    });
  });
});
