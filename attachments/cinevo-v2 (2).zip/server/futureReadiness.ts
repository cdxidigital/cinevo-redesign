import * as db from "./db";
import { getJellyfinLibrarySections } from "./jellyfin";
import { getPlexLibrarySections } from "./plex";

type Provider = "plex" | "jellyfin";

function invitationLibraryCount(libraryIdsJson: string) {
  try {
    const ids: unknown = JSON.parse(libraryIdsJson);
    return Array.isArray(ids) ? ids.length : 0;
  } catch {
    return 0;
  }
}

async function checkProvider(userId: number, provider: Provider) {
  const connected = provider === "plex" ? await db.getPlexConnectionByUserId(userId) : await db.getJellyfinConnectionByUserId(userId);
  if (!connected) return { provider, status: "not_connected" as const, checkedAt: new Date(), sectionCount: 0 };

  try {
    const sections = provider === "plex" ? await getPlexLibrarySections(userId) : await getJellyfinLibrarySections(userId);
    return { provider, status: "reachable" as const, checkedAt: new Date(), sectionCount: sections.length };
  } catch {
    return { provider, status: "unreachable" as const, checkedAt: new Date(), sectionCount: 0 };
  }
}

export async function getFutureReadinessOverview(userId: number) {
  const [libraries, invites, plex, jellyfin] = await Promise.all([
    db.listCinevoLibraries(userId),
    db.listCinevoShareInvites(userId),
    checkProvider(userId, "plex"),
    checkProvider(userId, "jellyfin"),
  ]);
  const now = Date.now();
  const expiringWithin48Hours = invites.filter((invite) => invite.status !== "revoked" && new Date(invite.expiresAt).getTime() - now <= 48 * 60 * 60 * 1000 && new Date(invite.expiresAt).getTime() > now).length;
  const selectedLibraries = libraries.filter((library) => library.isSelected);
  return {
    health: [plex, jellyfin],
    metadataRefresh: {
      selectedLibraries: selectedLibraries.length,
      needsRefresh: selectedLibraries.filter((library) => library.scanState !== "complete").length,
      canRequest: selectedLibraries.length > 0,
      note: "Refresh is always requested manually from your selected library. CINEVO does not run background scans.",
    },
    shareSafety: {
      active: invites.filter((invite) => invite.status === "active" || invite.status === "pending").length,
      expiringWithin48Hours,
      revoked: invites.filter((invite) => invite.status === "revoked").length,
    },
    playback: {
      status: "not_configured" as const,
      note: "CINEVO is ready to receive an owner-approved playback route from your connected media server. No playback address is stored or exposed yet.",
    },
  };
}

export async function buildOwnerExport(userId: number) {
  const [libraries, invites, aiPreference, notificationPreference] = await Promise.all([
    db.listCinevoLibraries(userId),
    db.listCinevoShareInvites(userId),
    db.getCinevoAiPreference(userId),
    db.getCinevoNotificationPreference(userId),
  ]);
  return {
    format: "cinevo-owner-settings-v1",
    exportedAt: new Date().toISOString(),
    notice: "This export contains CINEVO settings and sharing metadata only. It never contains media files, artwork bytes, Plex tokens, Jellyfin tokens, passwords, or server addresses.",
    selectedLibraries: libraries.filter((library) => library.isSelected).map((library) => ({ provider: library.provider, name: library.name, kind: library.kind, scanState: library.scanState, lastScanAt: library.lastScanAt })),
    invitations: invites.map((invite) => ({ recipientLabel: invite.recipientLabel, status: invite.status, libraryCount: invitationLibraryCount(invite.libraryIdsJson), expiresAt: invite.expiresAt, createdAt: invite.createdAt })),
    ai: aiPreference ? { enabled: aiPreference.isEnabled, scope: aiPreference.scope } : { enabled: false, scope: "active_library" },
    alerts: notificationPreference ? { emailEnabled: notificationPreference.emailEnabled, provider: notificationPreference.provider, libraryEvents: notificationPreference.libraryEvents, sharingEvents: notificationPreference.sharingEvents, privacyEvents: notificationPreference.privacyEvents } : { emailEnabled: false, provider: "none" },
  };
}
