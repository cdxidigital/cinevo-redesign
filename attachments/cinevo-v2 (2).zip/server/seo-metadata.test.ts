import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const rootDocument = readFileSync(new URL("../client/index.html", import.meta.url), "utf8");

function metaContent(name: string) {
  const match = rootDocument.match(new RegExp(`<meta\\s+name="${name}"\\s+content="([^"]+)"`, "i"));
  return match?.[1];
}

describe("CINEVO homepage SEO metadata", () => {
  it("has a concise meta description within the required 50–160 character range", () => {
    const description = metaContent("description");
    expect(description).toBeDefined();
    expect(description!.length).toBeGreaterThanOrEqual(50);
    expect(description!.length).toBeLessThanOrEqual(160);
  });

  it("has between three and eight focused keywords", () => {
    const keywordContent = metaContent("keywords");
    expect(keywordContent).toBeDefined();
    const keywords = keywordContent!.split(",").map((keyword) => keyword.trim()).filter(Boolean);
    expect(keywords).toHaveLength(6);
    expect(keywords.length).toBeGreaterThanOrEqual(3);
    expect(keywords.length).toBeLessThanOrEqual(8);
  });
});
