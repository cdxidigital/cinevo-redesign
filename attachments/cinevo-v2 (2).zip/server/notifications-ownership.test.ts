import { beforeEach, describe, expect, it, vi } from "vitest";

const database = vi.hoisted(() => ({
  clearCinevoNotifications: vi.fn(),
  createCinevoNotification: vi.fn(),
  dismissCinevoNotification: vi.fn(),
  getCinevoNotificationPreference: vi.fn(),
  listCinevoNotifications: vi.fn(),
  markCinevoNotificationRead: vi.fn(),
  saveCinevoNotificationPreference: vi.fn(),
  updateCinevoNotificationDeliveryState: vi.fn(),
}));

vi.mock("./db", () => database);

import { emitCinevoNotification, getNotificationCentre, notificationActions } from "./notifications";

describe("CINEVO notification ownership and state", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    database.getCinevoNotificationPreference.mockResolvedValue(undefined);
    database.listCinevoNotifications.mockResolvedValue([
      { id: 3, userId: 41, title: "Library ready", readAt: null, dismissedAt: null, createdAt: new Date() },
      { id: 2, userId: 41, title: "Privacy reviewed", readAt: new Date(), dismissedAt: null, createdAt: new Date() },
    ]);
  });

  it("lists only through the requesting owner identifier and derives unread count", async () => {
    const result = await getNotificationCentre(41);
    expect(database.listCinevoNotifications).toHaveBeenCalledWith(41);
    expect(result.unreadCount).toBe(1);
    expect(result.preference.emailEnabled).toBe(false);
  });

  it("passes the owner identifier through read, dismiss, and clear actions", async () => {
    await notificationActions.markRead(41, 3);
    await notificationActions.dismiss(41, 3);
    await notificationActions.clearAll(41);
    expect(database.markCinevoNotificationRead).toHaveBeenCalledWith(41, 3);
    expect(database.dismissCinevoNotification).toHaveBeenCalledWith(41, 3);
    expect(database.clearCinevoNotifications).toHaveBeenCalledWith(41);
  });

  it("creates the in-app notice while keeping email disabled by default", async () => {
    database.createCinevoNotification.mockResolvedValue({ id: 9, userId: 41 });
    const result = await emitCinevoNotification(41, {
      category: "library",
      severity: "success",
      title: "Library ready",
      message: "Your selected library is ready.",
    });
    expect(database.createCinevoNotification).toHaveBeenCalledWith(expect.objectContaining({ userId: 41, category: "library" }));
    expect(database.updateCinevoNotificationDeliveryState).toHaveBeenCalledWith(41, 9, "disabled");
    expect(result.email).toEqual({ delivered: false, reason: "disabled" });
  });
});
