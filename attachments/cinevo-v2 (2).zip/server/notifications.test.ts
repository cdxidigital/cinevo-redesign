import { afterEach, describe, expect, it } from "vitest";
import { buildResendRequest, buildSendGridRequest, emailProviderConfigured, type NotificationEvent } from "./notifications";

const event: NotificationEvent = {
  category: "sharing",
  severity: "success",
  title: "Private invitation created",
  message: "A time-bound invitation was created for one selected library.",
  actionHref: "/app?core=sharing",
};

const originalEnv = { ...process.env };

afterEach(() => {
  process.env = { ...originalEnv };
});

describe("CINEVO email alert adapters", () => {
  it("keeps both providers disabled until all private server values exist", () => {
    delete process.env.RESEND_API_KEY;
    delete process.env.SENDGRID_API_KEY;
    delete process.env.CINEVO_EMAIL_FROM;
    delete process.env.CINEVO_ALERT_RECIPIENT_EMAIL;
    expect(emailProviderConfigured("resend")).toBe(false);
    expect(emailProviderConfigured("sendgrid")).toBe(false);
  });

  it("builds a minimal Resend request with bearer authentication", () => {
    process.env.RESEND_API_KEY = "resend-test-key";
    process.env.CINEVO_EMAIL_FROM = "alerts@updates.example.com";
    process.env.CINEVO_ALERT_RECIPIENT_EMAIL = "owner@example.com";
    const request = buildResendRequest(event);
    expect(request.url).toBe("https://api.resend.com/emails");
    expect(request.init.headers.Authorization).toBe("Bearer resend-test-key");
    expect(JSON.parse(request.init.body)).toMatchObject({
      from: "alerts@updates.example.com",
      to: ["owner@example.com"],
      subject: "CINEVO — Private invitation created",
    });
  });

  it("builds a SendGrid Mail Send request with only required recipient content", () => {
    process.env.SENDGRID_API_KEY = "sendgrid-test-key";
    process.env.CINEVO_EMAIL_FROM = "alerts@updates.example.com";
    process.env.CINEVO_ALERT_RECIPIENT_EMAIL = "owner@example.com";
    const request = buildSendGridRequest(event);
    expect(request.url).toBe("https://api.sendgrid.com/v3/mail/send");
    expect(request.init.headers.Authorization).toBe("Bearer sendgrid-test-key");
    expect(JSON.parse(request.init.body)).toMatchObject({
      personalizations: [{ to: [{ email: "owner@example.com" }] }],
      from: { email: "alerts@updates.example.com" },
      subject: "CINEVO — Private invitation created",
    });
  });
});
