import { invokeLLM, listLLMModels } from "./_core/llm";
import * as db from "./db";
import { selectedHomeLibraryMetadata } from "./homeLibrary";

export async function getAiConsent(userId: number) {
  return (await db.getCinevoAiPreference(userId)) ?? { isEnabled: false, scope: "active_library" as const };
}

export async function setAiConsent(userId: number, isEnabled: boolean, scope: "active_library" | "selected_libraries") {
  const preference = await db.saveCinevoAiPreference({ userId, isEnabled, scope });
  if (isEnabled) await db.recordCinevoStewardshipEvent({ userId, type: "ai_enabled", points: 4 });
  return preference;
}

export async function askLibraryConcierge(userId: number, question: string, activeLibraryId?: number) {
  const preference = await getAiConsent(userId);
  if (!preference.isEnabled) throw new Error("Enable AI consent before asking CINEVO about your library");
  const trimmed = question.trim();
  if (!trimmed || trimmed.length > 600) throw new Error("Ask a concise library question of up to 600 characters");
  let metadata;
  if (preference.scope === "active_library") {
    if (!activeLibraryId) throw new Error("Choose one selected library for this private AI question");
    const activeLibrary = (await db.listCinevoLibraries(userId)).find((library) => library.id === activeLibraryId && library.isSelected);
    if (!activeLibrary) throw new Error("Choose a selected library you control");
    metadata = await selectedHomeLibraryMetadata(userId, 80, [activeLibraryId]);
  } else {
    metadata = await selectedHomeLibraryMetadata(userId);
  }
  if (!metadata.length) throw new Error("Select and scan at least one library before asking CINEVO");
  const { data: models } = await listLLMModels();
  const model = models.find((entry) => entry.id === "gpt-5-mini")?.id ?? models[0]?.id;
  if (!model) throw new Error("CINEVO AI is temporarily unavailable");
  const result = await invokeLLM({
    model,
    messages: [
      { role: "system", content: "You are CINEVO, a private home-library concierge. Use only the supplied metadata. Do not claim to stream, access, or train on media files. Give a concise, practical answer in plain text. If the answer cannot be supported by the metadata, say so." },
      { role: "user", content: `Selected metadata: ${JSON.stringify(metadata)}\n\nQuestion: ${trimmed}` },
    ],
    maxTokens: 500,
  });
  const content = result.choices[0]?.message.content;
  const answer = typeof content === "string" ? content.trim() : "CINEVO could not form a response from the selected metadata.";
  return { answer, consultedItems: metadata.length };
}
