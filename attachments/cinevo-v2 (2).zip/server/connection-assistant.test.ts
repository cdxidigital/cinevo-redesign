import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { buildJellyfinConnectionPayload, buildPlexConnectionPayload } from "../client/src/lib/connection-assistant";

const cinevoAppSource = readFileSync(fileURLToPath(new URL("../client/src/pages/CinevoApp.tsx", import.meta.url)), "utf8");

describe("CINEVO Plex connection assistant", () => {
  it("extracts a secure server address and token from one pasted Plex link", () => {
    expect(buildPlexConnectionPayload({
      connectionLink: "https://plex.example.com/library/metadata/42?X-Plex-Token=token-123",
      baseUrl: "",
      token: "",
    })).toEqual({ baseUrl: "https://plex.example.com", token: "token-123" });
  });

  it("accepts the manual address and token fallback while normalizing the address", () => {
    expect(buildPlexConnectionPayload({ connectionLink: "", baseUrl: "media.example.com/", token: "safe-token" })).toEqual({ baseUrl: "https://media.example.com", token: "safe-token" });
  });

  it("rejects an insecure or tokenless quick-connect link", () => {
    expect(() => buildPlexConnectionPayload({ connectionLink: "http://plex.example.com/?X-Plex-Token=x", baseUrl: "", token: "" })).toThrow("secure HTTPS");
    expect(() => buildPlexConnectionPayload({ connectionLink: "https://plex.example.com/", baseUrl: "", token: "" })).toThrow("missing an X-Plex-Token");
  });

  it("normalizes a secure Jellyfin address and rejects insecure input", () => {
    expect(buildJellyfinConnectionPayload({ baseUrl: "library.example.com/", username: "parker", password: "private" })).toMatchObject({ baseUrl: "https://library.example.com", username: "parker" });
    expect(() => buildJellyfinConnectionPayload({ baseUrl: "http://library.example.com", username: "parker", password: "private" })).toThrow("secure HTTPS");
  });

  it("keeps error recovery and reconnect actions visible in the guided Plex interface", () => {
    expect(cinevoAppSource).toContain("connection-modal__error");
    expect(cinevoAppSource).toContain("Use server address and token instead");
    expect(cinevoAppSource).toContain('connection.connected ? "Reconnect" : "Connect"');
  });
});
