import type { Express } from "express";
import { sdk } from "./_core/sdk";
import { proxyJellyfinImage } from "./jellyfin";

export function registerJellyfinProxy(app: Express) {
  app.get("/api/jellyfin/image/:itemId", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const imageType = typeof req.query.type === "string" ? req.query.type : "Primary";
      await proxyJellyfinImage({ userId: user.id, itemId: req.params.itemId, imageType, response: res });
    } catch (error) {
      console.error("[Jellyfin] Image proxy failed", error);
      res.status(401).json({ error: "Unable to load this library image" });
    }
  });
}
