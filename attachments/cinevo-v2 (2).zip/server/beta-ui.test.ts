import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const project = resolve(import.meta.dirname, "..");
const read = (path: string) => readFileSync(resolve(project, path), "utf8");

describe("CINEVO beta interface safeguards", () => {
  it("uses accessible skeleton semantics only for private-library loading", () => {
    const app = read("client/src/pages/CinevoApp.tsx");
    expect(app).toContain('role="status"');
    expect(app).toContain('aria-busy="true"');
    expect(app).toContain("Loading titles from your private library.");
    expect(app).not.toContain('from "@/lib/cinevo-data"');
  });

  it("persists a user-controlled appearance preference", () => {
    const theme = read("client/src/contexts/ThemeContext.tsx");
    const app = read("client/src/App.tsx");
    expect(theme).toContain('localStorage.getItem("theme")');
    expect(theme).toContain('localStorage.setItem("theme", theme)');
    expect(app).toContain('switchable');
  });

  it("declares complete social cards with a canonical CINEVO URL and PNG artwork", () => {
    const html = read("client/index.html");
    expect(html).toContain('rel="canonical" href="https://cinevo.cdxi.click/"');
    expect(html).toContain('property="og:type" content="website"');
    expect(html).toContain('property="og:image" content="https://cinevo.cdxi.click/manus-storage/cinevo-og-social_ef30dc5d.png"');
    expect(html).toContain('name="twitter:card" content="summary_large_image"');
    expect(html).toContain('name="twitter:image" content="https://cinevo.cdxi.click/manus-storage/cinevo-og-social_ef30dc5d.png"');
  });
});
