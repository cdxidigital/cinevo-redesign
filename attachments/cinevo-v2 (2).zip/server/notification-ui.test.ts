import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const component = readFileSync(fileURLToPath(new URL("../client/src/components/NotificationCenter.tsx", import.meta.url)), "utf8");
const styles = readFileSync(fileURLToPath(new URL("../client/src/components/notification-center-position.css", import.meta.url)), "utf8");

describe("notification centre keyboard semantics", () => {
  it("supports Escape dismissal and exposes labelled actionable controls", () => {
    expect(component).toContain('event.key === "Escape"');
    expect(component).toContain('aria-label="Close notifications"');
    expect(component).toContain('aria-label={`Dismiss ${item.title}`}');
  });

  it("provides explicit focus-visible treatment for buttons and form controls", () => {
    expect(styles).toContain(".notification-panel button:focus-visible");
    expect(styles).toContain(".notification-panel input:focus-visible");
    expect(styles).toContain(".notification-panel select:focus-visible");
    expect(styles).toContain("outline: 2px solid #61def7");
  });
});
