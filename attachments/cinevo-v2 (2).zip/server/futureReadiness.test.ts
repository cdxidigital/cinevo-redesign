import { describe, expect, it, vi } from "vitest";

const database = vi.hoisted(() => ({
  getPlexConnectionByUserId: vi.fn(), getJellyfinConnectionByUserId: vi.fn(), listCinevoLibraries: vi.fn(), listCinevoShareInvites: vi.fn(), getCinevoAiPreference: vi.fn(), getCinevoNotificationPreference: vi.fn(),
}));
const sources = vi.hoisted(() => ({ getPlexLibrarySections: vi.fn(), getJellyfinLibrarySections: vi.fn() }));
vi.mock("./db", () => database);
vi.mock("./plex", () => ({ getPlexLibrarySections: sources.getPlexLibrarySections }));
vi.mock("./jellyfin", () => ({ getJellyfinLibrarySections: sources.getJellyfinLibrarySections }));

import { buildOwnerExport, getFutureReadinessOverview } from "./futureReadiness";

describe("future readiness export", () => {
  it("summarises manual server health and share safety without background work or connection secrets", async () => {
    database.getPlexConnectionByUserId.mockResolvedValue({ id: 1 });
    database.getJellyfinConnectionByUserId.mockResolvedValue(undefined);
    database.listCinevoLibraries.mockResolvedValue([{ id: 8, isSelected: true, provider: "plex", name: "Films", kind: "movie", scanState: "requested" }]);
    database.listCinevoShareInvites.mockResolvedValue([{ status: "active", expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) }, { status: "revoked", expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) }]);
    sources.getPlexLibrarySections.mockResolvedValue([{ id: "films" }, { id: "series" }]);
    const result = await getFutureReadinessOverview(42);
    expect(result.health).toEqual(expect.arrayContaining([expect.objectContaining({ provider: "plex", status: "reachable", sectionCount: 2 }), expect.objectContaining({ provider: "jellyfin", status: "not_connected" })]));
    expect(result.metadataRefresh).toMatchObject({ selectedLibraries: 1, needsRefresh: 1, canRequest: true });
    expect(result.shareSafety).toMatchObject({ active: 1, expiringWithin48Hours: 1, revoked: 1 });
    expect(JSON.stringify(result)).not.toContain("baseUrl");
  });

  it("returns owner settings without provider credentials or server locations", async () => {
    database.listCinevoLibraries.mockResolvedValue([{ isSelected: true, provider: "plex", name: "Films", kind: "movie", scanState: "complete", lastScanAt: new Date() }]);
    database.listCinevoShareInvites.mockResolvedValue([{ recipientLabel: "Household", status: "active", libraryIdsJson: "[2]", expiresAt: new Date(), createdAt: new Date(), inviteToken: "must-not-leak" }]);
    database.getCinevoAiPreference.mockResolvedValue({ isEnabled: true, scope: "selected_libraries" });
    database.getCinevoNotificationPreference.mockResolvedValue({ emailEnabled: true, provider: "resend", libraryEvents: true, sharingEvents: true, privacyEvents: true });
    const result = await buildOwnerExport(42);
    const serialized = JSON.stringify(result);
    expect(serialized).not.toContain("must-not-leak");
    expect(serialized).not.toContain("baseUrl");
    expect(result.selectedLibraries).toEqual([expect.objectContaining({ name: "Films" })]);
  });
});
