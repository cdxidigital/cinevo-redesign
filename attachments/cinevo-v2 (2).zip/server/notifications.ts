import {
  clearCinevoNotifications,
  createCinevoNotification,
  dismissCinevoNotification,
  getCinevoNotificationPreference,
  listCinevoNotifications,
  markCinevoNotificationRead,
  saveCinevoNotificationPreference,
  updateCinevoNotificationDeliveryState,
} from "./db";

export type NotificationCategory = "library" | "sharing" | "privacy" | "account";
export type NotificationSeverity = "info" | "success" | "attention";
export type EmailProvider = "none" | "resend" | "sendgrid";

export type NotificationEvent = {
  category: NotificationCategory;
  severity: NotificationSeverity;
  title: string;
  message: string;
  actionHref?: string;
};

const categoryPreference = {
  library: "libraryEvents",
  sharing: "sharingEvents",
  privacy: "privacyEvents",
  account: "privacyEvents",
} as const;

export function emailProviderConfigured(provider: EmailProvider) {
  if (provider === "resend") return Boolean(process.env.RESEND_API_KEY && process.env.CINEVO_EMAIL_FROM && process.env.CINEVO_ALERT_RECIPIENT_EMAIL);
  if (provider === "sendgrid") return Boolean(process.env.SENDGRID_API_KEY && process.env.CINEVO_EMAIL_FROM && process.env.CINEVO_ALERT_RECIPIENT_EMAIL);
  return false;
}

export function buildResendRequest(event: NotificationEvent) {
  return {
    url: "https://api.resend.com/emails",
    init: {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY ?? ""}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.CINEVO_EMAIL_FROM,
        to: [process.env.CINEVO_ALERT_RECIPIENT_EMAIL],
        subject: `CINEVO — ${event.title}`,
        text: `${event.message}\n\nOpen CINEVO: ${process.env.CINEVO_APP_URL ?? "https://cinevov2-pcwdrvga.manus.space/app"}`,
      }),
    },
  };
}

export function buildSendGridRequest(event: NotificationEvent) {
  return {
    url: "https://api.sendgrid.com/v3/mail/send",
    init: {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.SENDGRID_API_KEY ?? ""}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: process.env.CINEVO_ALERT_RECIPIENT_EMAIL }] }],
        from: { email: process.env.CINEVO_EMAIL_FROM },
        subject: `CINEVO — ${event.title}`,
        content: [{ type: "text/plain", value: `${event.message}\n\nOpen CINEVO: ${process.env.CINEVO_APP_URL ?? "https://cinevov2-pcwdrvga.manus.space/app"}` }],
      }),
    },
  };
}

async function deliverEmail(provider: EmailProvider, event: NotificationEvent) {
  if (!emailProviderConfigured(provider)) return { delivered: false, reason: "provider_not_configured" as const };
  const request = provider === "resend" ? buildResendRequest(event) : buildSendGridRequest(event);
  const response = await fetch(request.url, request.init);
  if (!response.ok) throw new Error(`${provider} delivery returned ${response.status}`);
  return { delivered: true, provider } as const;
}

export async function emitCinevoNotification(userId: number, event: NotificationEvent) {
  const notification = await createCinevoNotification({ userId, ...event });
  const preference = await getCinevoNotificationPreference(userId);
  if (!preference?.emailEnabled || preference.provider === "none" || !preference[categoryPreference[event.category]]) {
    await updateCinevoNotificationDeliveryState(userId, notification.id, "disabled");
    return { notification, email: { delivered: false, reason: "disabled" as const } };
  }
  try {
    const email = await deliverEmail(preference.provider, event);
    await updateCinevoNotificationDeliveryState(userId, notification.id, email.delivered ? "sent" : "disabled");
    return { notification, email };
  } catch (error) {
    console.warn("[CINEVO notifications] Email delivery failed:", error instanceof Error ? error.message : error);
    await updateCinevoNotificationDeliveryState(userId, notification.id, "failed");
    return { notification, email: { delivered: false, reason: "delivery_failed" as const } };
  }
}

export async function getNotificationCentre(userId: number) {
  const [items, savedPreference] = await Promise.all([listCinevoNotifications(userId), getCinevoNotificationPreference(userId)]);
  const preference = savedPreference ?? { emailEnabled: false, provider: "none" as const, libraryEvents: true, sharingEvents: true, privacyEvents: true };
  return {
    items,
    unreadCount: items.filter((item) => !item.readAt).length,
    preference,
    availableProviders: { resend: emailProviderConfigured("resend"), sendgrid: emailProviderConfigured("sendgrid") },
  };
}

export async function updateNotificationPreference(userId: number, input: { emailEnabled: boolean; provider: EmailProvider; libraryEvents: boolean; sharingEvents: boolean; privacyEvents: boolean }) {
  return saveCinevoNotificationPreference({ userId, ...input });
}

export const notificationActions = {
  markRead: markCinevoNotificationRead,
  dismiss: dismissCinevoNotification,
  clearAll: clearCinevoNotifications,
};
