import { randomUUID } from "crypto";
import type { Response } from "express";
import * as db from "./db";
import { decryptJellyfinToken, encryptJellyfinToken, normalizeJellyfinUrl, type CinevoLibraryItem } from "./jellyfin";

const CLIENT_PRODUCT = "CINEVO";
const CLIENT_VERSION = "2.0.0";
const allowedImageTypes = new Set(["Primary", "Backdrop"]);

type PlexMetadata = {
  ratingKey: string | number;
  title?: string;
  type?: "movie" | "show";
  year?: number;
  duration?: number;
  summary?: string;
  Genre?: Array<{ tag?: string }>;
  Role?: Array<{ tag?: string }>;
  rating?: number;
  addedAt?: number;
  viewOffset?: number;
  thumb?: string;
  art?: string;
};

type PlexMediaContainer<T> = {
  MediaContainer?: T & {
    friendlyName?: string;
    machineIdentifier?: string;
    Directory?: Array<{ key?: string | number; type?: string }>;
    Metadata?: PlexMetadata[];
  };
};

export type CinevoPlexLibrary = {
  externalId: string;
  name: string;
  kind: "movie" | "series" | "music" | "photo" | "mixed";
  itemCount: number;
};

function plexHeaders(token: string, clientIdentifier: string, extra?: HeadersInit) {
  return {
    Accept: "application/json",
    "X-Plex-Token": token,
    "X-Plex-Client-Identifier": clientIdentifier,
    "X-Plex-Product": CLIENT_PRODUCT,
    "X-Plex-Version": CLIENT_VERSION,
    "X-Plex-Platform": "Web",
    ...extra,
  };
}

function millisecondsToRuntime(milliseconds?: number) {
  if (!milliseconds || milliseconds <= 0) return "—";
  const minutes = Math.round(milliseconds / 60_000);
  const hours = Math.floor(minutes / 60);
  return hours ? `${hours}h ${String(minutes % 60).padStart(2, "0")}m` : `${minutes}m`;
}

function progressForItem(item: PlexMetadata) {
  if (!item.viewOffset || !item.duration) return null;
  const progress = Math.round((item.viewOffset / item.duration) * 100);
  return progress > 0 && progress < 100 ? progress : null;
}

export function normalizePlexItem(item: PlexMetadata): CinevoLibraryItem {
  const genres = (item.Genre ?? []).map((genre) => genre.tag).filter((genre): genre is string => Boolean(genre));
  const id = String(item.ratingKey);
  return {
    id,
    source: "plex",
    title: item.title || "Untitled",
    kind: item.type === "show" ? "series" : "movie",
    year: item.year ? String(item.year) : "—",
    runtime: millisecondsToRuntime(item.duration),
    genre: genres[0] ?? "Uncategorised",
    genres,
    synopsis: item.summary || "No synopsis is available in this library.",
    cast: (item.Role ?? []).map((person) => person.tag).filter((name): name is string => Boolean(name)).slice(0, 5),
    rating: typeof item.rating === "number" ? item.rating : null,
    addedAt: item.addedAt ? new Date(item.addedAt * 1000).toISOString() : null,
    progress: progressForItem(item),
    isFavorite: false,
    primaryImageUrl: item.thumb ? `/api/plex/image/${encodeURIComponent(id)}?type=Primary` : null,
    backdropImageUrl: item.art ? `/api/plex/image/${encodeURIComponent(id)}?type=Backdrop` : null,
  };
}

async function connectionForUser(userId: number) {
  const connection = await db.getPlexConnectionByUserId(userId);
  if (!connection) throw new Error("Connect your Plex library first");
  return { ...connection, accessToken: decryptJellyfinToken(connection.encryptedAccessToken) };
}

async function plexFetch(userId: number, path: string, init?: RequestInit) {
  const connection = await connectionForUser(userId);
  const response = await fetch(`${connection.baseUrl}${path}`, {
    ...init,
    headers: plexHeaders(connection.accessToken, connection.clientIdentifier, init?.headers),
  });
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) throw new Error("Your Plex session has expired. Reconnect your library to continue.");
    throw new Error("CINEVO could not reach your Plex Media Server. Check the address and remote access settings.");
  }
  return response;
}

export async function connectPlexLibrary(input: { userId: number; baseUrl: string; token: string }) {
  const baseUrl = normalizeJellyfinUrl(input.baseUrl);
  const token = input.token.trim();
  if (!token) throw new Error("Add a Plex access token");
  const clientIdentifier = randomUUID();
  const response = await fetch(`${baseUrl}/`, { headers: plexHeaders(token, clientIdentifier) });
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) throw new Error("Plex could not verify that access token");
    throw new Error("CINEVO could not reach that Plex Media Server. Check the address and remote access settings.");
  }
  const data = await response.json() as PlexMediaContainer<Record<string, never>>;
  const server = data.MediaContainer;
  if (!server?.machineIdentifier) throw new Error("Plex did not return a usable Media Server identity");
  await db.savePlexConnection({
    userId: input.userId,
    baseUrl,
    displayName: server.friendlyName || "Plex Media Server",
    machineIdentifier: server.machineIdentifier,
    encryptedAccessToken: encryptJellyfinToken(token),
    clientIdentifier,
  });
  return { displayName: server.friendlyName || "Plex Media Server" };
}

export async function getPlexLibrary(userId: number) {
  const sections = await getPlexLibrarySections(userId);
  return getPlexLibraryItemsForSections(userId, sections.map((section) => section.externalId));
}

export async function getPlexLibrarySections(userId: number): Promise<CinevoPlexLibrary[]> {
  const response = await plexFetch(userId, "/library/sections");
  const data = await response.json() as PlexMediaContainer<Record<string, never>>;
  return (data.MediaContainer?.Directory ?? []).filter((section) => section.type === "movie" || section.type === "show").map((section) => ({
    externalId: String(section.key),
    name: section.type === "show" ? "Series" : "Films",
    kind: section.type === "show" ? "series" : "movie",
    itemCount: 0,
  }));
}

export async function getPlexLibraryItemsForSections(userId: number, sectionIds: string[]) {
  const itemLists = await Promise.all(sectionIds.map(async (sectionId) => {
    const response = await plexFetch(userId, `/library/sections/${encodeURIComponent(sectionId)}/all?includeGuids=1`, {
      headers: { "X-Plex-Container-Start": "0", "X-Plex-Container-Size": "200" },
    });
    const data = await response.json() as PlexMediaContainer<Record<string, never>>;
    return data.MediaContainer?.Metadata ?? [];
  }));
  return itemLists.flat().map(normalizePlexItem).sort((a, b) => (b.addedAt || "").localeCompare(a.addedAt || ""));
}

export async function requestPlexLibraryScan(userId: number, sectionId: string) {
  await plexFetch(userId, `/library/sections/${encodeURIComponent(sectionId)}/refresh`, { method: "POST" });
  return { requested: true };
}

export async function proxyPlexImage(input: { userId: number; itemId: string; imageType: string; response: Response }) {
  if (!allowedImageTypes.has(input.imageType)) {
    input.response.status(400).json({ error: "Unsupported image type" });
    return;
  }
  const endpoint = `/library/metadata/${encodeURIComponent(input.itemId)}/${input.imageType === "Backdrop" ? "art" : "thumb"}`;
  const upstream = await plexFetch(input.userId, endpoint);
  input.response.setHeader("Cache-Control", "private, max-age=3600");
  input.response.setHeader("Content-Type", upstream.headers.get("content-type") || "image/jpeg");
  input.response.status(upstream.status).send(Buffer.from(await upstream.arrayBuffer()));
}

export async function getPlexConnectionStatus(userId: number) {
  const connection = await db.getPlexConnectionByUserId(userId);
  return connection ? { connected: true, displayName: connection.displayName } : { connected: false, displayName: null };
}

export async function disconnectPlexLibrary(userId: number) {
  await db.deletePlexConnectionByUserId(userId);
  return { success: true };
}
