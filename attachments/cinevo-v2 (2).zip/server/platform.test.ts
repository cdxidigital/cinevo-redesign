import { beforeEach, describe, expect, it, vi } from "vitest";

const { database, sources, llm } = vi.hoisted(() => ({
  database: {
    getPlexConnectionByUserId: vi.fn(),
    getJellyfinConnectionByUserId: vi.fn(),
    listCinevoLibraries: vi.fn(),
    saveCinevoLibraries: vi.fn(),
    setSelectedCinevoLibraries: vi.fn(),
    updateCinevoLibraryScan: vi.fn(),
    createCinevoShareInvite: vi.fn(),
    listCinevoShareInvites: vi.fn(),
    updateCinevoShareInvite: vi.fn(),
    recordCinevoStewardshipEvent: vi.fn(),
    getCinevoStewardship: vi.fn(),
    getCinevoAiPreference: vi.fn(),
    saveCinevoAiPreference: vi.fn(),
  },
  sources: {
    getPlexLibrarySections: vi.fn(),
    getPlexLibraryItemsForSections: vi.fn(),
    requestPlexLibraryScan: vi.fn(),
    getJellyfinLibrarySections: vi.fn(),
    getJellyfinLibraryItemsForSections: vi.fn(),
    requestJellyfinLibraryScan: vi.fn(),
  },
  llm: { invokeLLM: vi.fn(), listLLMModels: vi.fn() },
}));

vi.mock("./db", () => database);
vi.mock("./plex", () => ({ getPlexLibrarySections: sources.getPlexLibrarySections, getPlexLibraryItemsForSections: sources.getPlexLibraryItemsForSections, requestPlexLibraryScan: sources.requestPlexLibraryScan }));
vi.mock("./jellyfin", () => ({ getJellyfinLibrarySections: sources.getJellyfinLibrarySections, getJellyfinLibraryItemsForSections: sources.getJellyfinLibraryItemsForSections, requestJellyfinLibraryScan: sources.requestJellyfinLibraryScan }));
vi.mock("./_core/llm", () => ({ invokeLLM: llm.invokeLLM, listLLMModels: llm.listLLMModels }));

import { askLibraryConcierge } from "./aiConcierge";
import { scanHomeLibrary, selectedHomeLibraryItems, selectHomeLibraries } from "./homeLibrary";
import { createPrivateInvite, listPrivateInvites } from "./sharing";

const ownedSelectedLibrary = { id: 12, userId: 4, provider: "plex", externalId: "5", name: "Films", kind: "movie", isSelected: true, scanState: "idle", itemCount: 0, lastScanAt: null, createdAt: new Date(), updatedAt: new Date() } as const;

describe("CINEVO platform permission boundaries", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    database.listCinevoLibraries.mockResolvedValue([ownedSelectedLibrary]);
  });

  it("refuses library selection outside the owner’s own connected servers", async () => {
    await expect(selectHomeLibraries(4, [99])).rejects.toThrow("own connected servers");
    expect(database.setSelectedCinevoLibraries).not.toHaveBeenCalled();
  });

  it("refuses a scan until the owner has selected that library", async () => {
    database.listCinevoLibraries.mockResolvedValue([{ ...ownedSelectedLibrary, isSelected: false }]);
    await expect(scanHomeLibrary(4, 12)).rejects.toThrow("Select this library");
    expect(database.updateCinevoLibraryScan).not.toHaveBeenCalled();
  });

  it("refuses friend invitations for libraries not selected by the owner", async () => {
    database.listCinevoLibraries.mockResolvedValue([{ ...ownedSelectedLibrary, isSelected: false }]);
    await expect(createPrivateInvite({ ownerUserId: 4, recipientLabel: "Alex", libraryIds: [12], expiresInDays: 7 })).rejects.toThrow("Only selected private libraries");
    expect(database.createCinevoShareInvite).not.toHaveBeenCalled();
  });

  it("marks expired invitations as expired when listing owner invitations", async () => {
    const expiredInvite = { id: 3, ownerUserId: 4, inviteToken: "private", recipientLabel: "Alex", libraryIdsJson: "[12]", status: "active", expiresAt: new Date(Date.now() - 1_000), createdAt: new Date(), updatedAt: new Date() } as const;
    database.listCinevoShareInvites.mockResolvedValue([expiredInvite]);
    const invites = await listPrivateInvites(4);
    expect(database.updateCinevoShareInvite).toHaveBeenCalledWith(4, 3, "expired");
    expect(invites[0]?.status).toBe("expired");
  });

  it("refuses concierge requests until the owner explicitly enables AI consent", async () => {
    database.getCinevoAiPreference.mockResolvedValue({ isEnabled: false, scope: "selected_libraries" });
    await expect(askLibraryConcierge(4, "Find a mystery film")).rejects.toThrow("Enable AI consent");
  });

  it("returns media only from owner-selected Plex and Jellyfin sections", async () => {
    database.listCinevoLibraries.mockResolvedValue([
      ownedSelectedLibrary,
      { ...ownedSelectedLibrary, id: 13, externalId: "9", name: "Archive", isSelected: false },
      { ...ownedSelectedLibrary, id: 14, provider: "jellyfin", externalId: "21", name: "Series", kind: "series" },
      { ...ownedSelectedLibrary, id: 15, provider: "jellyfin", externalId: "22", name: "Hidden", kind: "series", isSelected: false },
    ]);
    sources.getPlexLibraryItemsForSections.mockResolvedValue([{ id: "plex-1", title: "Selected film", addedAt: "2026-01-02" }]);
    sources.getJellyfinLibraryItemsForSections.mockResolvedValue([{ id: "jelly-1", title: "Selected series", addedAt: "2026-01-01" }]);

    const items = await selectedHomeLibraryItems(4);

    expect(sources.getPlexLibraryItemsForSections).toHaveBeenCalledWith(4, ["5"]);
    expect(sources.getJellyfinLibraryItemsForSections).toHaveBeenCalledWith(4, ["21"]);
    expect(items.map((item) => item.title)).toEqual(["Selected film", "Selected series"]);
  });

  it("requires an owner-selected library when AI consent is scoped to one active library", async () => {
    database.getCinevoAiPreference.mockResolvedValue({ isEnabled: true, scope: "active_library" });
    await expect(askLibraryConcierge(4, "Find a mystery film")).rejects.toThrow("Choose one selected library");
    await expect(askLibraryConcierge(4, "Find a mystery film", 99)).rejects.toThrow("Choose a selected library");
  });
});
