import type { Express } from "express";
import { sdk } from "./_core/sdk";
import { proxyPlexImage } from "./plex";

export function registerPlexProxy(app: Express) {
  app.get("/api/plex/image/:itemId", async (req, res) => {
    try {
      const user = await sdk.authenticateRequest(req);
      const imageType = typeof req.query.type === "string" ? req.query.type : "Primary";
      await proxyPlexImage({ userId: user.id, itemId: req.params.itemId, imageType, response: res });
    } catch (error) {
      console.error("[Plex] Image proxy failed", error);
      res.status(401).json({ error: "Unable to load this library image" });
    }
  });
}
