import { createCipheriv, createDecipheriv, createHash, randomUUID } from "crypto";
import type { Response } from "express";
import * as db from "./db";
import { ENV } from "./_core/env";

const CLIENT_NAME = "CINEVO";
const DEVICE_NAME = "CINEVO Web";
const CLIENT_VERSION = "2.0.0";
const TOKEN_SEPARATOR = ".";
const allowedImageTypes = new Set(["Primary", "Backdrop"]);

type JellyfinApiItem = {
  Id: string;
  Name?: string;
  Type?: string;
  ProductionYear?: number;
  PremiereDate?: string;
  RunTimeTicks?: number;
  Genres?: string[];
  Overview?: string;
  People?: Array<{ Name?: string }>;
  CommunityRating?: number;
  DateCreated?: string;
  ImageTags?: { Primary?: string };
  BackdropImageTags?: string[];
  UserData?: {
    IsFavorite?: boolean;
    PlaybackPositionTicks?: number;
    Played?: boolean;
  };
};

type JellyfinLibraryView = {
  Id: string;
  Name?: string;
  CollectionType?: string;
};

export type CinevoProviderLibrary = {
  externalId: string;
  name: string;
  kind: "movie" | "series" | "music" | "photo" | "mixed";
  itemCount: number;
};

export type CinevoLibraryItem = {
  id: string;
  source: "jellyfin" | "plex";
  title: string;
  kind: "movie" | "series";
  year: string;
  runtime: string;
  genre: string;
  genres: string[];
  synopsis: string;
  cast: string[];
  rating: number | null;
  addedAt: string | null;
  progress: number | null;
  isFavorite: boolean;
  primaryImageUrl: string | null;
  backdropImageUrl: string | null;
};

function encryptionKey() {
  if (!ENV.cookieSecret) throw new Error("Application encryption key is unavailable");
  return createHash("sha256").update(ENV.cookieSecret).digest();
}

export function encryptJellyfinToken(token: string) {
  const iv = Buffer.from(randomUUID().replaceAll("-", "").slice(0, 24), "hex");
  const cipher = createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const encrypted = Buffer.concat([cipher.update(token, "utf8"), cipher.final()]);
  return [iv.toString("base64url"), cipher.getAuthTag().toString("base64url"), encrypted.toString("base64url")].join(TOKEN_SEPARATOR);
}

export function decryptJellyfinToken(value: string) {
  const [iv, tag, encrypted] = value.split(TOKEN_SEPARATOR);
  if (!iv || !tag || !encrypted) throw new Error("Saved Jellyfin access token is invalid");
  const decipher = createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(iv, "base64url"));
  decipher.setAuthTag(Buffer.from(tag, "base64url"));
  return Buffer.concat([decipher.update(Buffer.from(encrypted, "base64url")), decipher.final()]).toString("utf8");
}

export function normalizeJellyfinUrl(value: string) {
  const candidate = value.trim();
  if (!candidate) throw new Error("Add your Jellyfin library address");
  let parsed: URL;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new Error("Use a complete HTTPS library address");
  }
  if (parsed.protocol !== "https:" || parsed.username || parsed.password) {
    throw new Error("Use a secure HTTPS library address without embedded credentials");
  }
  parsed.hash = "";
  parsed.search = "";
  return parsed.toString().replace(/\/$/, "");
}

function authorizationHeader(deviceId: string, token?: string) {
  const fragments = [
    `Client="${CLIENT_NAME}"`,
    `Device="${DEVICE_NAME}"`,
    `DeviceId="${deviceId}"`,
    `Version="${CLIENT_VERSION}"`,
  ];
  if (token) fragments.push(`Token="${token}"`);
  return `MediaBrowser ${fragments.join(", ")}`;
}

function ticksToRuntime(ticks?: number) {
  if (!ticks || ticks <= 0) return "—";
  const minutes = Math.round(ticks / 10_000_000 / 60);
  const hours = Math.floor(minutes / 60);
  return hours ? `${hours}h ${String(minutes % 60).padStart(2, "0")}m` : `${minutes}m`;
}

function progressFromUserData(item: JellyfinApiItem) {
  const position = item.UserData?.PlaybackPositionTicks;
  if (!position || !item.RunTimeTicks || item.UserData?.Played) return null;
  const result = Math.round((position / item.RunTimeTicks) * 100);
  return result > 0 && result < 100 ? result : null;
}

export function normalizeJellyfinItem(item: JellyfinApiItem): CinevoLibraryItem {
  const genres = (item.Genres ?? []).filter(Boolean);
  const primaryImageUrl = item.ImageTags?.Primary ? `/api/jellyfin/image/${encodeURIComponent(item.Id)}?type=Primary` : null;
  const backdropImageUrl = item.BackdropImageTags?.length ? `/api/jellyfin/image/${encodeURIComponent(item.Id)}?type=Backdrop` : null;
  return {
    id: item.Id,
    source: "jellyfin",
    title: item.Name || "Untitled",
    kind: item.Type === "Series" ? "series" : "movie",
    year: item.ProductionYear ? String(item.ProductionYear) : item.PremiereDate?.slice(0, 4) ?? "—",
    runtime: ticksToRuntime(item.RunTimeTicks),
    genre: genres[0] ?? "Uncategorised",
    genres,
    synopsis: item.Overview || "No synopsis is available in this library.",
    cast: (item.People ?? []).map((person) => person.Name).filter((name): name is string => Boolean(name)).slice(0, 5),
    rating: typeof item.CommunityRating === "number" ? item.CommunityRating : null,
    addedAt: item.DateCreated ?? null,
    progress: progressFromUserData(item),
    isFavorite: Boolean(item.UserData?.IsFavorite),
    primaryImageUrl,
    backdropImageUrl,
  };
}

function libraryParams(userId: string, parentId?: string) {
  const params = new URLSearchParams({
    userId,
    includeItemTypes: "Movie,Series",
    recursive: "true",
    fields: "Overview,People,Genres,ImageTags,BackdropImageTags,UserData,CommunityRating,DateCreated,RunTimeTicks,PremiereDate,ProductionYear",
    sortBy: "DateCreated",
    sortOrder: "Descending",
    limit: "200",
  });
  if (parentId) params.set("parentId", parentId);
  return params;
}

async function connectionForUser(userId: number) {
  const connection = await db.getJellyfinConnectionByUserId(userId);
  if (!connection) throw new Error("Connect your Jellyfin library first");
  return { ...connection, accessToken: decryptJellyfinToken(connection.encryptedAccessToken) };
}

async function jellyfinFetch(userId: number, path: string, init?: RequestInit) {
  const connection = await connectionForUser(userId);
  const response = await fetch(`${connection.baseUrl}${path}`, {
    ...init,
    headers: {
      "X-Emby-Authorization": authorizationHeader(connection.deviceId, connection.accessToken),
      ...(init?.headers ?? {}),
    },
  });
  if (!response.ok) {
    if (response.status === 401 || response.status === 403) throw new Error("Your Jellyfin session has expired. Reconnect your library to continue.");
    throw new Error("CINEVO could not reach your Jellyfin library. Check the library address and remote access settings.");
  }
  return response;
}

export async function connectJellyfinLibrary(input: { userId: number; baseUrl: string; username: string; password: string }) {
  const baseUrl = normalizeJellyfinUrl(input.baseUrl);
  const deviceId = randomUUID();
  const response = await fetch(`${baseUrl}/Users/AuthenticateByName`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Emby-Authorization": authorizationHeader(deviceId),
    },
    body: JSON.stringify({ Username: input.username.trim(), Pw: input.password }),
  });
  if (!response.ok) {
    if (response.status === 401) throw new Error("Jellyfin could not verify those sign-in details");
    throw new Error("CINEVO could not reach that Jellyfin library. Check the address and remote access settings.");
  }
  const data = await response.json() as { AccessToken?: string; User?: { Id?: string; Name?: string } };
  if (!data.AccessToken || !data.User?.Id) throw new Error("Jellyfin did not return a usable library session");
  await db.saveJellyfinConnection({
    userId: input.userId,
    baseUrl,
    jellyfinUserId: data.User.Id,
    displayName: data.User.Name || input.username.trim() || "Jellyfin user",
    encryptedAccessToken: encryptJellyfinToken(data.AccessToken),
    deviceId,
  });
  return { displayName: data.User.Name || input.username.trim() || "Jellyfin user" };
}

export async function getJellyfinLibrary(userId: number) {
  const connection = await connectionForUser(userId);
  const response = await jellyfinFetch(userId, `/Users/${encodeURIComponent(connection.jellyfinUserId)}/Items?${libraryParams(connection.jellyfinUserId).toString()}`);
  const data = await response.json() as { Items?: JellyfinApiItem[] };
  return (data.Items ?? []).map(normalizeJellyfinItem);
}

function libraryKind(value?: string): CinevoProviderLibrary["kind"] {
  if (value === "movies") return "movie";
  if (value === "tvshows") return "series";
  if (value === "music") return "music";
  if (value === "photos") return "photo";
  return "mixed";
}

export async function getJellyfinLibrarySections(userId: number): Promise<CinevoProviderLibrary[]> {
  const connection = await connectionForUser(userId);
  const response = await jellyfinFetch(userId, `/Users/${encodeURIComponent(connection.jellyfinUserId)}/Views`);
  const data = await response.json() as { Items?: JellyfinLibraryView[] };
  return (data.Items ?? []).map((item) => ({ externalId: item.Id, name: item.Name || "Untitled library", kind: libraryKind(item.CollectionType), itemCount: 0 }));
}

export async function getJellyfinLibraryItemsForSections(userId: number, sectionIds: string[]) {
  const connection = await connectionForUser(userId);
  const itemLists = await Promise.all(sectionIds.map(async (sectionId) => {
    const response = await jellyfinFetch(userId, `/Users/${encodeURIComponent(connection.jellyfinUserId)}/Items?${libraryParams(connection.jellyfinUserId, sectionId).toString()}`);
    const data = await response.json() as { Items?: JellyfinApiItem[] };
    return (data.Items ?? []).map(normalizeJellyfinItem);
  }));
  return itemLists.flat();
}

export async function requestJellyfinLibraryScan(userId: number, sectionId: string) {
  await jellyfinFetch(userId, `/Items/${encodeURIComponent(sectionId)}/Refresh`, { method: "POST" });
  return { requested: true };
}

export async function setJellyfinFavorite(userId: number, itemId: string, isFavorite: boolean) {
  const connection = await connectionForUser(userId);
  const endpoint = `/Users/${encodeURIComponent(connection.jellyfinUserId)}/FavoriteItems/${encodeURIComponent(itemId)}`;
  await jellyfinFetch(userId, endpoint, { method: isFavorite ? "POST" : "DELETE" });
  return { id: itemId, isFavorite };
}

export async function proxyJellyfinImage(input: { userId: number; itemId: string; imageType: string; response: Response }) {
  if (!allowedImageTypes.has(input.imageType)) {
    input.response.status(400).json({ error: "Unsupported image type" });
    return;
  }
  const endpoint = `/Items/${encodeURIComponent(input.itemId)}/Images/${input.imageType}`;
  const upstream = await jellyfinFetch(input.userId, endpoint);
  input.response.setHeader("Cache-Control", "private, max-age=3600");
  input.response.setHeader("Content-Type", upstream.headers.get("content-type") || "image/jpeg");
  input.response.status(upstream.status).send(Buffer.from(await upstream.arrayBuffer()));
}

export async function getJellyfinConnectionStatus(userId: number) {
  const connection = await db.getJellyfinConnectionByUserId(userId);
  return connection ? { connected: true, displayName: connection.displayName } : { connected: false, displayName: null };
}

export async function disconnectJellyfinLibrary(userId: number) {
  await db.deleteJellyfinConnectionByUserId(userId);
  return { success: true };
}
