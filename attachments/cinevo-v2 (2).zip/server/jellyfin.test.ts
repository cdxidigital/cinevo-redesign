import { describe, expect, it } from "vitest";
import { normalizeJellyfinItem, normalizeJellyfinUrl } from "./jellyfin";

describe("Jellyfin library normalization", () => {
  it("maps a Jellyfin media item into CINEVO’s browsing model", () => {
    const item = normalizeJellyfinItem({
      Id: "movie-1",
      Name: "Black Ice",
      Type: "Movie",
      ProductionYear: 2025,
      RunTimeTicks: 72_000_000_000,
      Genres: ["Drama", "Mystery"],
      Overview: "A northern mystery.",
      People: [{ Name: "Ava North" }],
      CommunityRating: 8.4,
      ImageTags: { Primary: "cover" },
      BackdropImageTags: ["backdrop"],
      UserData: { IsFavorite: true, PlaybackPositionTicks: 36_000_000_000 },
    });

    expect(item).toMatchObject({
      id: "movie-1",
      title: "Black Ice",
      kind: "movie",
      runtime: "2h 00m",
      genre: "Drama",
      rating: 8.4,
      progress: 50,
      isFavorite: true,
      primaryImageUrl: "/api/jellyfin/image/movie-1?type=Primary",
    });
  });

  it("requires a complete secure library address", () => {
    expect(normalizeJellyfinUrl("https://media.example.com/")).toBe("https://media.example.com");
    expect(() => normalizeJellyfinUrl("http://media.example.com")).toThrow("secure HTTPS");
  });
});
