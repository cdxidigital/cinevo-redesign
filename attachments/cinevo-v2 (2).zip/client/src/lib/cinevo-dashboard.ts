import type { JellyfinMediaItem } from "./jellyfin-library";

export type DashboardWidgetId = "playlist" | "continue" | "suggestions" | "my-list";

export const DEFAULT_DASHBOARD_WIDGETS: DashboardWidgetId[] = [
  "playlist",
  "continue",
  "suggestions",
  "my-list",
];

export type CinevoMood = "violet" | "noir" | "warm" | "electric";

export function deriveDashboard(items: JellyfinMediaItem[]) {
  const playList = items.filter((item) => item.progress !== null).slice(0, 4);
  const continueWatching = items.filter((item) => item.progress !== null);
  const suggestions = items.filter((item) => item.progress === null).slice(0, 8);
  const myList = items.filter((item) => item.isFavorite).slice(0, 8);
  return {
    featured: playList[0] ?? items[0] ?? null,
    playList,
    continueWatching,
    suggestions,
    myList,
  };
}

export function getCinevoMood(genres: string[]): CinevoMood {
  const normalized = genres.join(" ").toLowerCase();
  if (/(horror|thriller|crime|mystery|noir)/.test(normalized)) return "noir";
  if (/(romance|romantic|drama|comedy|musical)/.test(normalized)) return "warm";
  if (/(sci-fi|science fiction|action|adventure|fantasy|animation)/.test(normalized)) return "electric";
  return "violet";
}

export function moveDashboardWidget(
  order: DashboardWidgetId[],
  widget: DashboardWidgetId,
  direction: "up" | "down",
): DashboardWidgetId[] {
  const index = order.indexOf(widget);
  const nextIndex = direction === "up" ? index - 1 : index + 1;
  if (index < 0 || nextIndex < 0 || nextIndex >= order.length) return order;
  const next = [...order];
  [next[index], next[nextIndex]] = [next[nextIndex], next[index]];
  return next;
}

export function sanitizeDashboardWidgets(value: unknown): DashboardWidgetId[] {
  if (!Array.isArray(value)) return [...DEFAULT_DASHBOARD_WIDGETS];
  const valid = value.filter((item): item is DashboardWidgetId => DEFAULT_DASHBOARD_WIDGETS.includes(item as DashboardWidgetId));
  return Array.from(new Set(valid)).concat(DEFAULT_DASHBOARD_WIDGETS.filter((item) => !valid.includes(item)));
}
