import { DEFAULT_DASHBOARD_WIDGETS, sanitizeDashboardWidgets, type DashboardWidgetId } from "./cinevo-dashboard";

export type CinevoPreferences = {
  nightMode: boolean;
  zenMode: boolean;
  focusMode: boolean;
  audioHints: boolean;
  dashboardWidgets: DashboardWidgetId[];
};

export const DEFAULT_CINEVO_PREFERENCES: CinevoPreferences = {
  nightMode: true,
  zenMode: false,
  focusMode: false,
  audioHints: true,
  dashboardWidgets: [...DEFAULT_DASHBOARD_WIDGETS],
};

export function sanitizeCinevoPreferences(value: unknown): CinevoPreferences {
  if (!value || typeof value !== "object") return { ...DEFAULT_CINEVO_PREFERENCES, dashboardWidgets: [...DEFAULT_DASHBOARD_WIDGETS] };
  const candidate = value as Partial<CinevoPreferences>;
  return {
    nightMode: typeof candidate.nightMode === "boolean" ? candidate.nightMode : DEFAULT_CINEVO_PREFERENCES.nightMode,
    zenMode: typeof candidate.zenMode === "boolean" ? candidate.zenMode : DEFAULT_CINEVO_PREFERENCES.zenMode,
    focusMode: typeof candidate.focusMode === "boolean" ? candidate.focusMode : DEFAULT_CINEVO_PREFERENCES.focusMode,
    audioHints: typeof candidate.audioHints === "boolean" ? candidate.audioHints : DEFAULT_CINEVO_PREFERENCES.audioHints,
    dashboardWidgets: sanitizeDashboardWidgets(candidate.dashboardWidgets),
  };
}

export function loadCinevoPreferences(storage: Pick<Storage, "getItem"> | undefined): CinevoPreferences {
  if (!storage) return sanitizeCinevoPreferences(undefined);
  try {
    const raw = storage.getItem("cinevo-preferences");
    return sanitizeCinevoPreferences(raw ? JSON.parse(raw) : undefined);
  } catch {
    return sanitizeCinevoPreferences(undefined);
  }
}
