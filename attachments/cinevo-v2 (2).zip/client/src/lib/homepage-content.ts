export type HomeHighlight = {
  eyebrow: string;
  title: string;
  description: string;
  action: string;
};

export const homeHighlights: HomeHighlight[] = [
  {
    eyebrow: "PRIVATE LIBRARIES",
    title: "Choose exactly what belongs in view.",
    description: "Connect Plex or Jellyfin, then select the home-library sections CINEVO may index. Your media stays on your server.",
    action: "Set up libraries",
  },
  {
    eyebrow: "FRIEND SHARING",
    title: "Share with care, never by default.",
    description: "Create time-bound, revocable invitations for selected libraries. CINEVO makes the owner’s boundary visible at every step.",
    action: "Manage sharing",
  },
  {
    eyebrow: "CINEVO CORE",
    title: "A quieter way to care for your collection.",
    description: "Review library health, setup milestones, and consent controls without turning private media into a social performance.",
    action: "Explore Core",
  },
  {
    eyebrow: "CONSENT-LED AI",
    title: "Thoughtful suggestions on your terms.",
    description: "Choose one selected library or all selected libraries before asking CINEVO to work only with the metadata you allow.",
    action: "See AI controls",
  },
];

export const homeNav = [
  { label: "Home", href: "/" },
  { label: "Your library", href: "/app?core=libraries" },
  { label: "Sharing", href: "/app?core=sharing" },
  { label: "CINEVO Core", href: "/app?core=stewardship" },
] as const;
