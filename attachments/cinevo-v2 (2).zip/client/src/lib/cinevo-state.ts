export function toggleLocalList(currentIds: string[], itemId: string) {
  return currentIds.includes(itemId)
    ? currentIds.filter((currentId) => currentId !== itemId)
    : [...currentIds, itemId];
}

export function isSearchDismissKey(key: string) {
  return key === "Escape";
}

export function nextAudioTrackIndex(currentIndex: number, trackCount: number) {
  if (trackCount <= 0) return 0;
  return (currentIndex + 1) % trackCount;
}
