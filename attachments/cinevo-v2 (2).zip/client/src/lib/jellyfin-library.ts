export type JellyfinMediaItem = {
  id: string;
  source: "jellyfin" | "plex";
  title: string;
  kind: "movie" | "series";
  year: string;
  runtime: string;
  genre: string;
  genres: string[];
  synopsis: string;
  cast: string[];
  rating: number | null;
  addedAt: string | null;
  progress: number | null;
  isFavorite: boolean;
  primaryImageUrl: string | null;
  backdropImageUrl: string | null;
};

export type LibrarySearchFilters = {
  genre: string;
  year: string;
  minRating: number;
};

export const initialLibraryFilters: LibrarySearchFilters = {
  genre: "All genres",
  year: "All years",
  minRating: 0,
};

export function getLibraryGenres(items: JellyfinMediaItem[]) {
  return ["All genres", ...Array.from(new Set(items.flatMap((item) => item.genres))).sort((a, b) => a.localeCompare(b))];
}

export function getLibraryYears(items: JellyfinMediaItem[]) {
  return ["All years", ...Array.from(new Set(items.map((item) => item.year).filter((year) => /^\d{4}$/.test(year)))).sort((a, b) => Number(b) - Number(a))];
}

export function filterLibraryItems(items: JellyfinMediaItem[], query: string, filters: LibrarySearchFilters, kind: JellyfinMediaItem["kind"] | "all" = "all") {
  const normalizedQuery = query.trim().toLocaleLowerCase();
  return items.filter((item) => {
    const haystack = `${item.title} ${item.synopsis} ${item.genre} ${item.cast.join(" ")}`.toLocaleLowerCase();
    const matchesQuery = !normalizedQuery || haystack.includes(normalizedQuery);
    const matchesKind = kind === "all" || item.kind === kind;
    const matchesGenre = filters.genre === "All genres" || item.genres.includes(filters.genre);
    const matchesYear = filters.year === "All years" || item.year === filters.year;
    const matchesRating = filters.minRating === 0 || (item.rating ?? 0) >= filters.minRating;
    return matchesQuery && matchesKind && matchesGenre && matchesYear && matchesRating;
  });
}
