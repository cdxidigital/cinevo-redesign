export type PlexConnectionPayload = {
  baseUrl: string;
  token: string;
};

export type JellyfinConnectionPayload = {
  baseUrl: string;
  username: string;
  password: string;
};

function secureUrl(value: string) {
  const candidate = value.trim().startsWith("http") ? value.trim() : `https://${value.trim()}`;
  const url = new URL(candidate);
  if (url.protocol !== "https:") throw new Error("Use the secure HTTPS address for your Plex server");
  return url;
}

/**
 * Accepts either a Plex URL containing X-Plex-Token or the manual address/token fallback.
 * Values are intended for immediate form submission only; this helper never persists them.
 */
export function buildPlexConnectionPayload(input: { connectionLink: string; baseUrl: string; token: string }): PlexConnectionPayload {
  const connectionLink = input.connectionLink.trim();
  if (connectionLink) {
    const url = secureUrl(connectionLink);
    const token = url.searchParams.get("X-Plex-Token") || url.searchParams.get("x-plex-token");
    if (!token) throw new Error("That link is missing an X-Plex-Token. Use the manual option below instead.");
    url.search = "";
    url.hash = "";
    url.pathname = "/";
    return { baseUrl: url.toString().replace(/\/$/, ""), token };
  }

  const token = input.token.trim();
  if (!token) throw new Error("Add a Plex access token or paste a Plex connection link");
  const url = secureUrl(input.baseUrl);
  url.search = "";
  url.hash = "";
  return { baseUrl: url.toString().replace(/\/$/, ""), token };
}

export function buildJellyfinConnectionPayload(input: JellyfinConnectionPayload): JellyfinConnectionPayload {
  const username = input.username.trim();
  if (!username) throw new Error("Add your Jellyfin username");
  if (!input.password) throw new Error("Add your Jellyfin password");
  const url = secureUrl(input.baseUrl);
  url.search = "";
  url.hash = "";
  return { baseUrl: url.toString().replace(/\/$/, ""), username, password: input.password };
}
