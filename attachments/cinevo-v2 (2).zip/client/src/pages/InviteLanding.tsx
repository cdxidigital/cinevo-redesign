import { LibraryBig, LockKeyhole } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function InviteLanding() {
  const token = typeof window === "undefined" ? "" : decodeURIComponent(window.location.pathname.replace(/^\/invite\//, "").split("/")[0] ?? "");
  const invite = trpc.sharing.publicInvite.useQuery({ token }, { enabled: token.length >= 16, retry: false });
  const status = invite.data?.status;
  const ready = status === "pending" || status === "active";
  return <main className="invite-landing"><section><span className="preview-label">CINEVO · PRIVATE INVITATION</span><LockKeyhole size={26} /><h1>{invite.isLoading ? "Checking your invitation" : ready ? "You’ve been invited" : "This invitation is unavailable"}</h1>{invite.isLoading ? <p>Confirming the owner’s private sharing boundary.</p> : ready ? <><p>This invitation includes <b>{invite.data?.libraryCount} owner-selected {invite.data?.libraryCount === 1 ? "library" : "libraries"}</b> and expires on {invite.data?.expiresAt ? new Date(invite.data.expiresAt).toLocaleDateString() : "the owner’s chosen date"}.</p><div className="invite-landing__notice"><LibraryBig size={18} /><span>This page confirms a private invitation only. Media access is activated through the owner’s connected server and remains revocable at any time.</span></div></> : <p>{invite.error?.message || "The owner may have revoked this invitation or its access period may have ended."}</p>}<a className="quiet-action" href="/">Return to CINEVO</a></section></main>;
}
