import { ArrowDownRight, ArrowRight, Check, Play, ShieldCheck, Sparkles } from "lucide-react";
import { homeHighlights, homeNav } from "@/lib/homepage-content";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import NotificationCenter from "@/components/NotificationCenter";
import ThemeToggle from "@/components/ThemeToggle";
import "./public-home.css";

export default function PublicHome() {
  const { isAuthenticated } = useAuth();
  const enterPrivateApp = (path = "/app") => { if (isAuthenticated) window.location.assign(path); else startLogin(); };

  return <div className="public-home">
    <header className="public-nav">
      <a className="public-brand" href="/" aria-label="CINEVO home"><span className="brand__mark"><i /></span><span><b>CINEVO</b><small>Private cinema, reinvented</small></span></a>
      <nav aria-label="Homepage navigation">{homeNav.map((item) => <a key={item.label} href={item.href}>{item.label}</a>)}</nav>
      <div className="public-nav__actions"><ThemeToggle /><NotificationCenter enabled={isAuthenticated} navVariant="public" /><button className="public-nav__enter" onClick={() => enterPrivateApp()}>{isAuthenticated ? "Open CINEVO" : "Sign in"} <ArrowRight size={14} /></button></div>
    </header>

    <main>
      <section className="public-hero" aria-labelledby="public-hero-title">
        <div className="public-hero__veil" />
        <div className="public-hero__orb" />
        <div className="public-hero__content">
          <span className="public-kicker"><i /> PRIVATE BY DESIGN</span>
          <h1 id="public-hero-title">Your media.<br /><em>Your moment.</em></h1>
          <p>CINEVO brings the libraries you control into a considered cinematic space—built around your collection, the people you trust, and choices you can always reverse.</p>
          <div className="public-hero__actions"><button className="public-primary" onClick={() => enterPrivateApp()}><Play size={15} fill="currentColor" /> Enter CINEVO</button><button className="public-secondary" onClick={() => enterPrivateApp("/app")}>Open your library <ArrowDownRight size={16} /></button></div>
        </div>
        <div className="public-hero__note"><ShieldCheck size={16} /><span><b>Private from the first connection</b><small>Personal media remains on your connected server.</small></span></div>
      </section>

      <section className="home-reel" aria-labelledby="home-reel-title">
        <header><div><span className="public-kicker">START WITH YOUR LIBRARY</span><h2 id="home-reel-title">Nothing appears here until you choose it.</h2></div><p>CINEVO never fills your library with sample media or imported catalogue data.</p></header>
        <div className="home-library-steps"><article><span>01</span><h3>Connect a server</h3><p>Add Plex or Jellyfin through your private CINEVO account.</p></article><article><span>02</span><h3>Choose sections</h3><p>Select only the movie and series libraries you want CINEVO to index.</p></article><article><span>03</span><h3>Make it yours</h3><p>Your connected library, watch state, and saved titles appear only after your choice.</p></article></div>
      </section>

      <section className="home-manifesto" id="libraries">
        <div className="home-manifesto__intro"><span className="public-kicker">THE PRIVATE MEDIA OS</span><h2>Every library is personal.<br /><em>So CINEVO starts with permission.</em></h2><p>Bring together the media you own and host without turning it into someone else’s platform. CINEVO is designed for an owner-first relationship with Plex and Jellyfin libraries.</p><a href="/app?connect=plex" className="public-text-link">Connect a library <ArrowRight size={15} /></a></div>
        <div className="home-manifesto__rules"><div><Check size={17} /><span><b>Select libraries deliberately</b><small>Choose the individual sections CINEVO can see.</small></span></div><div><Check size={17} /><span><b>Keep sharing intentional</b><small>Set library scope and expiry before every invite.</small></span></div><div><Check size={17} /><span><b>Stay in control of AI</b><small>Opt in and set the metadata scope for each request.</small></span></div></div>
      </section>

      <section className="home-highlights" id="sharing" aria-labelledby="home-highlights-title"><header><span className="public-kicker">A MORE CONSIDERED MEDIA LIFE</span><h2 id="home-highlights-title">Everything useful.<br />Nothing extractive.</h2></header><div className="home-highlights__grid">{homeHighlights.map((item, index) => <a key={item.eyebrow} href={index === 0 ? "/app?core=libraries" : index === 1 ? "/app?core=sharing" : index === 2 ? "/app?core=stewardship" : "/app?core=ai"} id={index === 2 ? "core" : undefined} className="home-highlight"><span>{String(index + 1).padStart(2, "0")}</span><em>{item.eyebrow}</em><h3>{item.title}</h3><p>{item.description}</p><b>{item.action} <ArrowRight size={14} /></b></a>)}</div></section>

      <section className="home-closing"><div><Sparkles size={18} /><span className="public-kicker">CINEMA, REINVENTED</span><h2>A home for your<br /><em>entire world of stories.</em></h2></div><div><p>Connect the server you trust. Choose what CINEVO knows. Then settle in.</p><a href="/app?connect=plex" className="public-primary">Begin with your library <ArrowRight size={16} /></a></div></section>
    </main>
    <footer className="public-footer"><a className="public-brand" href="/"><span className="brand__mark"><i /></span><span><b>CINEVO</b><small>Private cinema, reinvented</small></span></a><p>Your media. Your moment.</p><a href="/app?search=1">Search your library <ArrowRight size={13} /></a></footer>
  </div>;
}
