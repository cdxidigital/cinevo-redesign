import PublicHome from "./PublicHome";

export default function Home() {
  return <PublicHome />;
}
