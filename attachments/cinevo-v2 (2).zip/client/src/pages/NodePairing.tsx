import { ArrowLeft, CheckCircle2, Computer, KeyRound, Link2, LoaderCircle, RefreshCw, ShieldCheck, Unplug } from "lucide-react";
import { useState } from "react";
import "./node-pairing.css";

type Connection = { id: string; provider: "plex" | "jellyfin"; baseUrl: string; createdAt: string; updatedAt: string };
type Status = { deviceId: string; connections: Connection[] };

const defaultNodeAddress = "http://127.0.0.1:48184";

export default function NodePairing() {
  const [nodeAddress, setNodeAddress] = useState(defaultNodeAddress);
  const [pairingCode, setPairingCode] = useState("");
  const [sessionToken, setSessionToken] = useState("");
  const [status, setStatus] = useState<Status | null>(null);
  const [message, setMessage] = useState("Run CINEVO Node on this computer, then enter its short pairing code.");
  const [loading, setLoading] = useState(false);

  const base = nodeAddress.trim().replace(/\/$/, "");
  const checkNode = async () => {
    setLoading(true); setMessage("Checking your local CINEVO Node…");
    try {
      const response = await fetch(`${base}/health`);
      if (!response.ok) throw new Error("CINEVO Node is not responding");
      setMessage("CINEVO Node is ready. Enter the pairing code displayed in its terminal window.");
    } catch {
      setMessage("CINEVO Node was not found at this address. Confirm it is running on this computer and use the address it displays.");
    } finally { setLoading(false); }
  };

  const pair = async () => {
    if (!pairingCode.trim()) return setMessage("Enter the short code shown by CINEVO Node before pairing.");
    setLoading(true); setMessage("Creating a short-lived local pairing session…");
    try {
      const response = await fetch(`${base}/v1/pair`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: pairingCode.trim().toUpperCase() }) });
      const data = await response.json() as { token?: string; error?: string };
      if (!response.ok || !data.token) throw new Error(data.error || "Pairing was not accepted");
      setSessionToken(data.token);
      await getStatus(data.token);
      setMessage("This browser is paired for a short local session. Your media-server credentials remain in CINEVO Node.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "CINEVO Node could not complete pairing."); }
    finally { setLoading(false); }
  };

  const getStatus = async (token = sessionToken) => {
    if (!token) return;
    const response = await fetch(`${base}/v1/status`, { headers: { Authorization: `Bearer ${token}` } });
    const data = await response.json() as Status & { error?: string };
    if (!response.ok) throw new Error(data.error || "The local pairing session expired");
    setStatus(data);
  };

  const revoke = async (connectionId: string) => {
    if (!sessionToken) return;
    setLoading(true);
    try {
      const response = await fetch(`${base}/v1/connections/revoke`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${sessionToken}` }, body: JSON.stringify({ connectionId }) });
      const data = await response.json() as { error?: string };
      if (!response.ok) throw new Error(data.error || "CINEVO Node could not remove that connection");
      await getStatus(); setMessage("The local connection was removed. No remote account or media token was exposed.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "CINEVO Node could not remove that connection."); }
    finally { setLoading(false); }
  };

  return <main className="node-pairing-page"><nav><a href="/" aria-label="Return to CINEVO homepage"><ArrowLeft size={16} /> CINEVO</a><span>PRIVATE COMPANION</span></nav><section className="node-pairing-hero"><div><p className="node-eyebrow"><Computer size={14} /> CINEVO NODE</p><h1>Your private library,<br /><em>close to home.</em></h1><p className="node-lede">Pair this browser with the CINEVO Node running on your Mac or Windows PC. It stays local, uses a one-time code, and never sends your Plex or Jellyfin credentials to CINEVO.</p><div className="node-guarantees"><span><ShieldCheck size={15} /> Loopback only</span><span><KeyRound size={15} /> 10-minute pairing code</span><span><Link2 size={15} /> No media proxy</span></div></div><aside className="node-card"><header><div><i><Link2 size={17} /></i><span><b>Connect this device</b><small>Local pairing only</small></span></div><button type="button" onClick={checkNode} disabled={loading} aria-label="Check CINEVO Node"><RefreshCw size={15} className={loading ? "is-spinning" : ""} /></button></header><label><span>Local Node address</span><input value={nodeAddress} onChange={(event) => setNodeAddress(event.target.value)} placeholder={defaultNodeAddress} autoCapitalize="none" autoCorrect="off" /></label><label><span>Pairing code</span><input value={pairingCode} onChange={(event) => setPairingCode(event.target.value.toUpperCase())} placeholder="ABC-123" autoCapitalize="characters" autoCorrect="off" /></label><button className="node-pair-button" type="button" onClick={pair} disabled={loading}>{loading ? <LoaderCircle className="is-spinning" size={16} /> : <KeyRound size={16} />} Pair with CINEVO Node</button><p className={sessionToken ? "node-status is-success" : "node-status"}>{sessionToken && <CheckCircle2 size={14} />}{message}</p></aside></section>{status && <section className="node-connections"><div><p className="node-eyebrow">LOCAL STATUS</p><h2>Connected servers</h2><p>Only server names and addresses are shown here. Access tokens stay within CINEVO Node.</p></div><div className="node-connection-list">{status.connections.length ? status.connections.map((connection) => <article key={connection.id}><div><b>{connection.provider === "plex" ? "Plex" : "Jellyfin"}</b><span>{connection.baseUrl}</span></div><button type="button" onClick={() => revoke(connection.id)} disabled={loading}><Unplug size={14} /> Remove</button></article>) : <article className="node-empty"><b>No local media servers connected</b><span>Use the CINEVO Node setup process on this computer to add Plex or Jellyfin, then return here to pair and review the connection.</span></article>}</div></section>}<section className="node-steps"><div><b>01</b><span><strong>Start Node</strong><small>Open the CINEVO Node executable on the computer hosting your library.</small></span></div><div><b>02</b><span><strong>Pair once</strong><small>Enter the code shown locally. It expires after ten minutes.</small></span></div><div><b>03</b><span><strong>Stay in control</strong><small>Review connected servers here and remove them locally at any time.</small></span></div></section></main>;
}
