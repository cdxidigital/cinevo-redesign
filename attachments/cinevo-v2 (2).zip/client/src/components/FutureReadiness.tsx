import { Download, RefreshCw, ServerCog, ShieldCheck, TriangleAlert } from "lucide-react";
import { trpc } from "@/lib/trpc";
import "./future-readiness.css";

function downloadSnapshot(snapshot: unknown) {
  const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: "application/json" });
  const href = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = href;
  link.download = `cinevo-owner-settings-${new Date().toISOString().slice(0, 10)}.json`;
  link.click();
  URL.revokeObjectURL(href);
}

export default function FutureReadiness() {
  const readiness = trpc.future.overview.useQuery(undefined, { retry: false });
  const exportSettings = trpc.future.export.useMutation({ onSuccess: downloadSnapshot });
  if (readiness.isLoading) return <div className="future-readiness future-readiness--loading" aria-label="Loading CINEVO operations"><i /><i /><i /></div>;
  if (readiness.error || !readiness.data) return <section className="future-readiness"><p className="core-note">Operations information is unavailable right now. Reconnect your private media server and try again.</p><button className="quiet-action" onClick={() => readiness.refetch()}>Try again</button></section>;
  const { health, metadataRefresh, shareSafety, playback } = readiness.data;
  return <section className="future-readiness">
    <header className="core-panel__heading"><div><span className="preview-label">FUTURE READY</span><h3>Operations, on your terms.</h3><p>Check your private server only when you ask, review sharing safeguards, and export your CINEVO settings without exporting media or credentials.</p></div><button className="quiet-action" onClick={() => readiness.refetch()} disabled={readiness.isFetching}>{readiness.isFetching ? <RefreshCw className="spin" size={15} /> : <RefreshCw size={15} />} Check status</button></header>
    <div className="future-readiness__grid">
      <article><span><ServerCog size={17} /> Server health</span>{health.map((entry) => <p key={entry.provider}><b>{entry.provider === "plex" ? "Plex" : "Jellyfin"}</b><i className={`future-status future-status--${entry.status}`} />{entry.status === "reachable" ? `${entry.sectionCount} section${entry.sectionCount === 1 ? "" : "s"} available` : entry.status === "unreachable" ? "Unavailable — reconnect when ready" : "Not connected"}</p>)}</article>
      <article><span><RefreshCw size={17} /> Metadata refresh</span><strong>{metadataRefresh.canRequest ? `${metadataRefresh.selectedLibraries} selected` : "Nothing selected"}</strong><p>{metadataRefresh.needsRefresh ? `${metadataRefresh.needsRefresh} selected ${metadataRefresh.needsRefresh === 1 ? "library needs" : "libraries need"} a first scan.` : metadataRefresh.note}</p></article>
      <article><span><ShieldCheck size={17} /> Share safety</span><strong>{shareSafety.active} active invitation{shareSafety.active === 1 ? "" : "s"}</strong><p>{shareSafety.expiringWithin48Hours ? <><TriangleAlert size={13} /> {shareSafety.expiringWithin48Hours} expire within 48 hours.</> : "No invitations expire within 48 hours."}</p><small>{shareSafety.revoked} revoked invitation{shareSafety.revoked === 1 ? "" : "s"} remain in your private activity record.</small></article>
      <article><span><Download size={17} /> Owner data export</span><strong>Settings only</strong><p>Download a private record of CINEVO selections, invite states, and preferences.</p><button className="future-export" onClick={() => exportSettings.mutate()} disabled={exportSettings.isPending}>{exportSettings.isPending ? "Preparing…" : "Download settings"}</button></article>
    </div>
    <div className="future-playback"><span>Playback routing</span><p>{playback.note}</p><b>Owner configuration required</b></div>
  </section>;
}
