import { Compass, Film, Heart, Home, LayoutGrid, LogOut, Settings2, Sparkles, Tags, X } from "lucide-react";
import type { View } from "@/pages/CinevoApp";

export type CinevoSidebarProps = {
  view: View;
  open: boolean;
  onClose: () => void;
  onNavigate: (view: Exclude<View, "detail">) => void;
  onOpenSearch: () => void;
  onOpenCore: () => void;
  onOpenSettings: () => void;
  onLogout: () => void;
};

const primaryItems = [
  { label: "Home", view: "home" as const, icon: Home },
  { label: "Explore", view: "movies" as const, icon: Compass },
  { label: "Genres", view: "movies" as const, icon: Tags },
  { label: "Favourites", view: "list" as const, icon: Heart },
];

export default function CinevoSidebar({
  view,
  open,
  onClose,
  onNavigate,
  onOpenSearch,
  onOpenCore,
  onOpenSettings,
  onLogout,
}: CinevoSidebarProps) {
  return (
    <>
      <button className={`sidebar-backdrop ${open ? "is-open" : ""}`} onClick={onClose} aria-label="Close navigation" tabIndex={open ? 0 : -1} />
      <aside className={`cinevo-sidebar ${open ? "is-open" : ""}`} aria-label="CINEVO navigation">
        <div className="cinevo-sidebar__topline">
          <button className="sidebar-brand" onClick={() => { onNavigate("home"); onClose(); }} aria-label="CINEVO Home">
            <span className="brand__mark"><i /></span>
            <span><b>CINEVO</b><small>Private cinema</small></span>
          </button>
          <button className="sidebar-close" onClick={onClose} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <button className="sidebar-search" onClick={() => { onOpenSearch(); onClose(); }}><span>Search your library</span><kbd>⌘ K</kbd></button>
        <nav className="sidebar-nav" aria-label="Library">
          <span className="sidebar-label">Library</span>
          {primaryItems.map(({ label, view: target, icon: Icon }) => (
            <button key={label} className={view === target || (label === "Explore" && (view === "series" || view === "movies")) ? "is-active" : ""} onClick={() => { onNavigate(target); onClose(); }}>
              <Icon size={16} /> <span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-section">
          <span className="sidebar-label">Your space</span>
          <button onClick={() => { onOpenCore(); onClose(); }}><LayoutGrid size={16} /><span>CINEVO Core</span><Sparkles size={13} className="sidebar-spark" /></button>
          <button onClick={() => { onOpenSettings(); onClose(); }}><Settings2 size={16} /><span>Settings</span></button>
        </div>
        <div className="sidebar-footer">
          <div className="sidebar-privacy-note"><span className="sidebar-privacy-dot" /><span><b>Private by design</b><small>Only your selected libraries</small></span></div>
          <button className="sidebar-logout" onClick={onLogout}><LogOut size={16} /><span>Logout</span></button>
        </div>
      </aside>
    </>
  );
}
