import { Bell, CheckCheck, ChevronRight, LibraryBig, ShieldCheck, Sparkles, UserRoundPlus, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import "./notification-center.css";
import "./notification-center-position.css";

type NotificationCategory = "library" | "sharing" | "privacy" | "account";

const categoryIcon = {
  library: LibraryBig,
  sharing: UserRoundPlus,
  privacy: ShieldCheck,
  account: Sparkles,
} satisfies Record<NotificationCategory, typeof Bell>;

function timeLabel(value: Date | string) {
  const date = new Date(value);
  const distance = Date.now() - date.getTime();
  if (distance < 60_000) return "Now";
  if (distance < 3_600_000) return `${Math.max(1, Math.floor(distance / 60_000))}m`;
  if (distance < 86_400_000) return `${Math.floor(distance / 3_600_000)}h`;
  return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export default function NotificationCenter({ enabled = true, variant = "dark", navVariant }: { enabled?: boolean; variant?: "dark" | "nav"; navVariant?: "public" }) {
  const { isAuthenticated } = useAuth();
  const active = enabled && isAuthenticated;
  const [open, setOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [deliveryNotice, setDeliveryNotice] = useState("");
  const rootRef = useRef<HTMLDivElement>(null);
  const utils = trpc.useUtils();
  const centre = trpc.notifications.centre.useQuery(undefined, { enabled: active, retry: false, refetchOnWindowFocus: false });
  const invalidate = () => utils.notifications.centre.invalidate();
  const markRead = trpc.notifications.markRead.useMutation({ onSuccess: invalidate });
  const dismiss = trpc.notifications.dismiss.useMutation({ onSuccess: invalidate });
  const clearAll = trpc.notifications.clearAll.useMutation({ onSuccess: invalidate });
  const savePreference = trpc.notifications.savePreference.useMutation({
    onSuccess: async () => { await invalidate(); },
    onError: () => setDeliveryNotice("CINEVO could not save that alert preference. Please try again."),
  });
  const preference = centre.data?.preference;
  const items = centre.data?.items ?? [];
  const unread = centre.data?.unreadCount ?? 0;

  const grouped = useMemo(() => {
    const today: typeof items = [];
    const earlier: typeof items = [];
    const start = new Date(); start.setHours(0, 0, 0, 0);
    items.forEach((item) => (new Date(item.createdAt) >= start ? today : earlier).push(item));
    return { today, earlier };
  }, [items]);

  useEffect(() => {
    if (!open) return;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    const closeOutside = (event: MouseEvent) => { if (rootRef.current && !rootRef.current.contains(event.target as Node)) setOpen(false); };
    document.addEventListener("keydown", closeOnEscape);
    document.addEventListener("mousedown", closeOutside);
    return () => { document.removeEventListener("keydown", closeOnEscape); document.removeEventListener("mousedown", closeOutside); };
  }, [open]);

  if (!active) return null;

  const updatePreference = (patch: Partial<{ emailEnabled: boolean; provider: "none" | "resend" | "sendgrid"; libraryEvents: boolean; sharingEvents: boolean; privacyEvents: boolean }>) => {
    const next = {
      emailEnabled: preference?.emailEnabled ?? false,
      provider: preference?.provider ?? "none",
      libraryEvents: preference?.libraryEvents ?? true,
      sharingEvents: preference?.sharingEvents ?? true,
      privacyEvents: preference?.privacyEvents ?? true,
      ...patch,
    };
    setDeliveryNotice("");
    savePreference.mutate(next, { onSuccess: () => {
      const available = next.provider === "resend" ? centre.data?.availableProviders.resend : next.provider === "sendgrid" ? centre.data?.availableProviders.sendgrid : false;
      setDeliveryNotice(!next.emailEnabled ? "Saved. In-app notifications remain active; email alerts are paused." : next.provider === "none" ? "Saved. Choose Resend or SendGrid before enabling email delivery." : available ? "Saved. Selected CINEVO events will also be sent by email." : "Saved. Add the selected provider’s server keys to activate email delivery.");
      invalidate();
    } });
  };

  const deliveryLabel = (state: "not_requested" | "disabled" | "sent" | "failed") => state === "sent" ? "Email sent" : state === "failed" ? "Email delivery failed" : state === "disabled" ? "Email paused" : "In-app only";
  return <div className={`notification-centre notification-centre--${variant}`} ref={rootRef}>
    <button className="notification-bell" type="button" aria-label={`Notifications${unread ? `, ${unread} unread` : ""}`} aria-expanded={open} onClick={() => setOpen((value) => !value)}>
      <Bell size={18} />{unread > 0 && <span>{unread > 9 ? "9+" : unread}</span>}
    </button>
    {open && <section className="notification-panel" role="dialog" aria-modal="false" aria-label="CINEVO notifications">
      <header><div><span className="preview-label">PRIVATE ACTIVITY</span><h2>{showSettings ? "Alert settings" : "Notifications"}</h2></div><button type="button" onClick={() => setOpen(false)} aria-label="Close notifications"><X size={18} /></button></header>
      {showSettings ? <div className="notification-settings">
        <p>Email alerts are optional and disabled until a provider is configured privately on the server.</p>
        <label><span><b>Email alerts</b><small>Send selected CINEVO events to the owner inbox</small></span><input type="checkbox" checked={preference?.emailEnabled ?? false} onChange={(event) => updatePreference({ emailEnabled: event.target.checked })} /></label>
        <label><span><b>Provider</b><small>Choose the production delivery service</small></span><select value={preference?.provider ?? "none"} onChange={(event) => updatePreference({ provider: event.target.value as "none" | "resend" | "sendgrid" })}><option value="none">Not configured</option><option value="resend">Resend</option><option value="sendgrid">SendGrid</option></select></label>
        {(["libraryEvents", "sharingEvents", "privacyEvents"] as const).map((key) => <label key={key}><span><b>{key === "libraryEvents" ? "Library activity" : key === "sharingEvents" ? "Sharing activity" : "Privacy changes"}</b><small>Keep the corresponding event alerts</small></span><input type="checkbox" checked={preference?.[key] ?? true} onChange={(event) => updatePreference({ [key]: event.target.checked })} /></label>)}
        <div className="notification-provider-state"><i className={centre.data?.availableProviders.resend ? "is-ready" : ""} /> Resend {centre.data?.availableProviders.resend ? "ready" : "needs server keys"}<i className={centre.data?.availableProviders.sendgrid ? "is-ready" : ""} /> SendGrid {centre.data?.availableProviders.sendgrid ? "ready" : "needs server keys"}</div>{deliveryNotice && <p className="notification-delivery-notice" role="status">{deliveryNotice}</p>}
      </div> : <>
        <div className="notification-toolbar"><span>{unread ? `${unread} unread` : "You’re up to date"}</span><div>{unread > 0 && <button type="button" onClick={() => items.filter((item) => !item.readAt).forEach((item) => markRead.mutate({ id: item.id }))}><CheckCheck size={13} /> Mark all read</button>}<button type="button" onClick={() => clearAll.mutate()} disabled={!items.length}>Clear</button></div></div>
        <div className="notification-list">{centre.isLoading ? <div className="notification-empty"><i /><i /><i /></div> : items.length ? ([{ label: "Today", items: grouped.today }, { label: "Earlier", items: grouped.earlier }]).map((group) => group.items.length > 0 && <div className="notification-group" key={group.label}><span>{group.label}</span>{group.items.map((item) => { const Icon = categoryIcon[item.category as NotificationCategory]; return <article key={item.id} className={item.readAt ? "" : "is-unread"}><button className="notification-item" type="button" onClick={() => { if (!item.readAt) markRead.mutate({ id: item.id }); if (item.actionHref) window.location.assign(item.actionHref); }}><i className={`notification-item__icon notification-item__icon--${item.severity}`}><Icon size={16} /></i><span><b>{item.title}</b><small>{item.message}</small><em>{timeLabel(item.createdAt)} · {deliveryLabel(item.emailDeliveryState)}</em></span>{item.actionHref && <ChevronRight size={15} />}</button><button className="notification-dismiss" type="button" onClick={() => dismiss.mutate({ id: item.id })} aria-label={`Dismiss ${item.title}`}><X size={13} /></button></article>; })}</div>) : <div className="notification-empty"><Bell size={20} /><b>No notifications yet</b><p>Private library, sharing, and consent updates will appear here.</p></div>}</div>
      </>}
      <footer><button type="button" onClick={() => setShowSettings((value) => !value)}>{showSettings ? "Back to notifications" : "Notification settings"}</button></footer>
    </section>}
  </div>;
}
