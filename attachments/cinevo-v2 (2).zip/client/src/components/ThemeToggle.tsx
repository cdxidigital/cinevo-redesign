import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import "./theme-toggle.css";

export default function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();
  if (!toggleTheme) return null;
  const isDark = theme === "dark";
  return <button className="theme-toggle" type="button" aria-label={isDark ? "Use light appearance" : "Use dark appearance"} aria-pressed={isDark} title={isDark ? "Use light appearance" : "Use dark appearance"} onClick={toggleTheme}>
    <Sun size={14} aria-hidden="true" />
    <span className="theme-toggle__track" aria-hidden="true"><i /></span>
    <Moon size={14} aria-hidden="true" />
  </button>;
}
