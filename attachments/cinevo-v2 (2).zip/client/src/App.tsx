import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import NotificationCenter from "./components/NotificationCenter";
import "./components/node-launch.css";

const CinevoApp = lazy(() => import("./pages/CinevoApp"));
const InviteLanding = lazy(() => import("./pages/InviteLanding"));
const PublicHome = lazy(() => import("./pages/PublicHome"));
const NodePairing = lazy(() => import("./pages/NodePairing"));

function PrivateRouteLoading() {
  return <main className="route-loading" role="status" aria-live="polite"><span aria-hidden="true" /><p>Opening your private CINEVO space…</p></main>;
}

function App() {
  const isInvitation = typeof window !== "undefined" && window.location.pathname.startsWith("/invite/");
  const isPrivateApp = typeof window !== "undefined" && window.location.pathname.startsWith("/app");
  const isNodePairing = typeof window !== "undefined" && window.location.pathname === "/node";
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" switchable>
        <TooltipProvider>
          <Toaster />
          {isPrivateApp && <div className="private-notification-slot"><NotificationCenter variant="nav" /></div>}
          {isPrivateApp && <a className="node-launch" href="/node">CINEVO Node</a>}
          <Suspense fallback={<PrivateRouteLoading />}>{isInvitation ? <InviteLanding /> : isNodePairing ? <NodePairing /> : isPrivateApp ? <CinevoApp /> : <PublicHome />}</Suspense>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
