# CINEVO Node for macOS

Choose the disk image that matches your Mac: **Apple Silicon** for M-series Macs, or **Intel** for Intel-based Macs. Open the downloaded image, drag `CINEVO Node.app` to your Applications folder, then open it from Applications. On first launch, CINEVO Node opens its private local control dashboard.

The dashboard lets the owner verify Plex or Jellyfin, select only the home-library sections they want CINEVO to use, request a manual metadata scan, and create a short-lived pairing code. It is available only on the Mac running Node at `http://127.0.0.1:48184` unless the owner deliberately enables a trusted local-network controller.

> These internal release candidates are not signed or notarized. Before wider macOS distribution, an Apple Developer ID certificate must be used to sign the app bundle and submit it for notarization. macOS may otherwise prevent it from opening.
