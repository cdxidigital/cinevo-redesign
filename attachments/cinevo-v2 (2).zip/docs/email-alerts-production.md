# Production Email Alerts for CINEVO

**Author:** Manus AI  
**Recommended default:** Resend for the shortest setup path; SendGrid remains available through the same CINEVO adapter contract.

## Required server values

Configure these values in the CINEVO project’s **Secrets** settings. Never place them in client-side code, commit them to Git, or prefix them with `VITE_`.

| Variable | Resend | SendGrid | Example purpose |
|---|---:|---:|---|
| `RESEND_API_KEY` | Required | No | Server-side Resend bearer token |
| `SENDGRID_API_KEY` | No | Required | Server-side SendGrid bearer token |
| `CINEVO_EMAIL_FROM` | Required | Required | Verified sending address, such as `alerts@updates.cinevo.example` |
| `CINEVO_ALERT_RECIPIENT_EMAIL` | Required | Required | Private owner inbox receiving alerts |
| `CINEVO_APP_URL` | Optional | Optional | Production `/app` URL included in emails |

## Option A — Resend

Resend requires a verified domain before sending from that domain. Its documentation recommends using a dedicated subdomain to separate transactional-email reputation from the root domain.[1]

1. Create or sign in to a [Resend](https://resend.com/) account.
2. Open **Domains**, add a sending subdomain such as `updates.yourdomain.com`, and add the DNS records supplied by Resend. Wait until the domain reports **Verified**.
3. Open **API Keys**, choose **Create API Key**, name it `CINEVO Production`, choose **Sending access**, and restrict it to the verified domain where appropriate. Resend displays the key only once, so copy it immediately.[2]
4. Add `RESEND_API_KEY`, `CINEVO_EMAIL_FROM`, and `CINEVO_ALERT_RECIPIENT_EMAIL` to CINEVO’s server secrets.
5. In CINEVO, open the notification bell, choose **Notification settings**, select **Resend**, enable the categories you want, and then enable **Email alerts**.

The CINEVO adapter sends `POST https://api.resend.com/emails` with `Authorization: Bearer <RESEND_API_KEY>`. It sends plain-text transactional alerts containing no library credentials or personal media titles.

## Option B — Twilio SendGrid

SendGrid recommends API keys rather than account usernames and passwords because keys can be revoked and permission-scoped. For CINEVO, create a **Custom Access** key with Mail Send access rather than Full Access.[3]

1. Create or sign in to a [Twilio SendGrid](https://sendgrid.com/) account.
2. Open **Settings → Sender Authentication → Domain Authentication**. Choose the DNS host, enter the sending domain, keep automated security enabled where compatible, add SendGrid’s DNS records, and verify the domain.[4]
3. Open **Settings → API Keys**, choose **Create API Key**, name it `CINEVO Production`, select **Custom Access**, and grant only the required **Mail Send** permission. Copy the key when displayed; SendGrid does not show it again.[3]
4. Add `SENDGRID_API_KEY`, `CINEVO_EMAIL_FROM`, and `CINEVO_ALERT_RECIPIENT_EMAIL` to CINEVO’s server secrets.
5. In CINEVO notification settings, select **SendGrid**, enable the required categories, and enable **Email alerts**.

The CINEVO adapter sends `POST https://api.sendgrid.com/v3/mail/send` with bearer authentication. SendGrid documents a successful Mail Send request as **202 Accepted**.[3]

## Production verification

After configuration, use a low-risk action such as changing AI consent or requesting a library scan. Confirm that the event appears immediately in the in-app notification centre, then confirm the corresponding email arrives. If the in-app notice appears but email does not, verify that the chosen provider reports **ready** inside notification settings, the From address matches the authenticated domain, and the provider key has sending permission.

For production operation, enable only one email provider at a time. Rotate keys if exposure is suspected, review sender-domain health, and keep in-app notifications active even when email delivery is unavailable.

## References

[1]: https://resend.com/docs/dashboard/domains/introduction "Resend — Verified Domains"
[2]: https://resend.com/docs/create-an-api-key "Resend — Create an API Key"
[3]: https://www.twilio.com/docs/sendgrid/ui/account-and-settings/api-keys "Twilio SendGrid — API Keys"
[4]: https://www.twilio.com/docs/sendgrid/ui/account-and-settings/how-to-set-up-domain-authentication "Twilio SendGrid — Configure Domain Authentication"
