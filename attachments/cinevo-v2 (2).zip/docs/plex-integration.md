# CINEVO Plex Integration

## Connection model

CINEVO connects to a **Plex Media Server** that the signed-in CINEVO user controls. The user enters a publicly reachable HTTPS Plex Media Server address and a Plex access token directly into the in-app connection form. The token is never displayed after submission, never placed in browser artwork URLs, and is encrypted before it is stored in the CINEVO database.

Plex Media Server requests are made only from the CINEVO server. CINEVO sends the stored token using Plex's `X-Plex-Token` header and uses a unique `X-Plex-Client-Identifier` for the connection. Artwork is returned through an authenticated CINEVO proxy, so the token is not exposed to the client.

| CINEVO capability | Plex implementation |
|---|---|
| Connection check | Authenticated `GET /` against the chosen Plex Media Server |
| Library discovery | `GET /library/sections` filters for movie and show sections |
| Media browsing | `GET /library/sections/{id}/all` with JSON and pagination headers |
| Cover and backdrop artwork | Authenticated CINEVO proxies request the Plex metadata `thumb` or `art` resource |
| Filters | CINEVO normalizes Plex genres, year, rating, and media type into its shared search model |
| Resume rail | CINEVO derives a percentage from Plex `viewOffset` and `duration` metadata |

## Prerequisites

The Plex Media Server must be reachable by the deployed CINEVO application over HTTPS with a certificate trusted by the application runtime. A private LAN-only address is not accessible to a cloud-hosted CINEVO deployment. The Plex account token supplied must have access to the movie and television libraries to be shown.

> CINEVO does not request, store, or display a Plex account password. It accepts a pre-existing Plex access token only in the encrypted connection form.

## Quick connect

CINEVO now accepts a **single Plex media-information link** containing its `X-Plex-Token`. In Plex Web, open a title, choose **Get Info**, then **View XML**, and copy the secure address. Paste the complete link into **Connect Plex**. CINEVO derives the Media Server root address and access token locally in the connection form, then submits the two values over the protected connection flow. The token is removed from the server address before the encrypted connection is stored.

If the quick-connect link is unavailable, the assistant exposes a manual fallback for a secure Media Server address and existing Plex access token. CINEVO rejects non-HTTPS server addresses before attempting the connection.

## Current scope

CINEVO can browse connected Plex movies and series, display Plex artwork through the authenticated proxy, show metadata and progress, and apply genre, year, and rating filters. Plex source selection is available whenever Plex and Jellyfin are both connected. **Playback routing and Plex saved-title synchronisation are intentionally not yet implemented**, so CINEVO labels the player as a control preview and explains the limitation in the Plex My List view.

## References

1. [Plex Media Server API: headers, authentication, media types, and pagination](https://developer.plex.tv/pms/)
2. [Plex Support: Plex Media Server URL commands and library sections](https://support.plex.tv/articles/201638786-plex-media-server-url-commands/)
