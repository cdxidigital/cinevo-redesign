# CINEVO Node Architecture

CINEVO Node is a companion process, not a replacement media server. It runs locally on the Mac or Windows computer already hosting Plex or Jellyfin. Its design is deliberately **loopback-only**: it binds to `127.0.0.1`, refuses remote ingress, has no port-forwarding requirement, and does not stream or proxy media bytes.

| Layer | Responsibility | Deliberate boundary |
|---|---|---|
| CINEVO Node | Pairing, private server configuration, section discovery, selected-library metadata scan | No remote listening; no media relay |
| Plex or Jellyfin | Retains the actual media library, streaming server, user account, and library authority | CINEVO Node sends only local provider API requests |
| CINEVO web and Android clients | Initiate pairing, show state, and request owner-approved library actions | They never receive a media-server access token |

The foundation uses a short-lived pairing code, then a short-lived bearer session. It enumerates Plex library sections and Jellyfin virtual folders and can perform owner-requested metadata enumeration for selected sections. It has no public ingress and never returns stored connection tokens. The v0.1 foundation keeps local credentials in an owner-restricted configuration file; **native Keychain/Credential Manager integration is required before a public release**.

## Desktop package plan

The package configuration targets macOS Intel, macOS Apple Silicon, and Windows x64 with the maintained [yao-pkg/pkg](https://github.com/yao-pkg/pkg) executable packager, which is actively maintained and packages Node.js projects as executables.[1] Release candidates must then be signed and tested on the target OS. macOS distribution requires Apple code signing and notarization; Windows distribution should use an Authenticode certificate and reputation-building distribution channel.

## Android companion plan

The Android app should pair with CINEVO Node **only over a local, owner-approved link**. It should never scan arbitrary LAN hosts, store a Plex/Jellyfin token, or receive media bytes from CINEVO Node. The app may present Node health, pending scan state, selected libraries, and notification state, while native playback continues through the provider-supported path.

## Build validation

The local CINEVO Node service was compiled and tested with three focused checks. An isolated runtime verified its loopback health endpoint, created a pairing session using the first-run code, then returned a protected status response only when presented with the resulting short-lived bearer session. The same status route returned **401** without that bearer session. No real Plex, Jellyfin, user, or media credentials were used.

Portable macOS Intel, macOS Apple Silicon, and Windows x64 executable candidates were produced and their Mach-O or PE executable formats verified. CINEVO Android was built as a debug APK with Android API 35; its package identifier is `im.cinevo.app` and its visible app label is `CINEVO`. The debug APK is suitable for internal installation only and must be replaced by a keystore-signed release artifact for production distribution.

## References

[1]: https://github.com/yao-pkg/pkg "yao-pkg/pkg — Package Node.js projects into executables"
