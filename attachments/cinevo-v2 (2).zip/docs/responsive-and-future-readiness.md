# CINEVO Responsive and Future-Readiness Guide

## Dynamic sizing

CINEVO uses a mobile-first responsive system with bounded `clamp()` typography, intrinsic grid sizing, and a high-resolution layout tier beginning at `1900px`. The public entry, private browsing interface, Core controls, overlays, and Node pairing surface retain readable type and touch-friendly controls across compact mobile, tablet, desktop, ultrawide, and 4K displays.

At high resolutions, CINEVO increases content width, hero scale, browsing-card density, control hit areas, and modal reading measure rather than merely enlarging every surface. On compact widths, navigation remains concise, stacked information panels replace compressed multi-column layouts, and action buttons retain a minimum usable height.

## Operations panel

The owner-only **Operations** panel provides on-demand connected-server health checks, manual metadata-refresh readiness, invitation safety summaries, a credential-free owner-settings export, and an explicit playback-routing readiness state.

| Capability | What CINEVO does | What CINEVO does not do |
|---|---|---|
| Server health | Checks Plex and Jellyfin only when the owner selects **Check status** | Does not poll servers in the background or store health history automatically |
| Metadata refresh | Reports selected sections that need an initial scan | Does not scan without an owner action |
| Share safety | Highlights active, revoked, and soon-expiring invitations | Does not publish a library or disclose invitation tokens in exports |
| Owner export | Downloads CINEVO settings, selected-library descriptors, invitation state, AI consent, and alert preferences | Does not export media, artwork bytes, server addresses, passwords, or provider tokens |
| Playback readiness | States the configuration boundary before playback routing is enabled | Does not invent a playback endpoint or use substitute media |

## Privacy and operational limits

CINEVO remains a private control surface. An owner must connect a Plex or Jellyfin server, select library sections, and request scans explicitly. The Operations panel does not create persistent jobs, background workers, automated metadata refreshes, or external data syncs. Any later playback-routing implementation must be separately reviewed for provider permissions, secure local access, and owner consent.
