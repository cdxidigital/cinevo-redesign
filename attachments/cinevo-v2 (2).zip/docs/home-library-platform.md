# CINEVO Home-Library Platform

## Product boundary

CINEVO is an owner-controlled media operating surface. It **does not upload, host, publish, purchase, or redistribute** personal media. The owner connects a private Plex or Jellyfin server, selects the sections CINEVO may index, and can change those choices at any time.

## Home-library selection and scans

After connecting Plex or Jellyfin, the owner opens **CINEVO Core → Libraries** and selects the specific server sections to include. Only selected sections contribute to CINEVO’s combined browse, discovery, and AI metadata context. A manual scan requests a refresh directly from the relevant connected server before CINEVO re-reads its metadata. The account used with the media service must have that server’s refresh permission; CINEVO makes this prerequisite visible rather than overstating scan results.

## Friend sharing

Friend sharing is intentionally **invite-only**. An invitation is scoped to selected libraries, has a clear expiry of 1–30 days, and can be paused, restored, or revoked by the owner. CINEVO persists the invitation boundary and owner intent. Actual access delivery and media-server enforcement require a compatible owner-controlled server bridge or source-specific sharing configuration; the current interface makes that limitation explicit and does not claim remote recipient enforcement where it has not been connected.

## Stewardship

Stewardship points recognise owner-care actions: choosing a library, scanning it, creating or revoking an invitation, and reviewing AI consent. CINEVO does not reward viewing duration, social popularity, or compulsive consumption. The points total is a personal setup and hygiene signal, not a competitive score.

## Privacy & AI

The CINEVO concierge is off by default. Once the owner enables it, a request sends only title, type, release year, genre, and rating metadata from **selected** libraries to the server-side assistant. Media files, artwork bytes, credentials, friend details, and unselected libraries are excluded from the prompt. Consent is reversible in CINEVO Core at any time. The assistant is instructed to answer only from the supplied metadata and never imply access to or training on media files.

## Validation status

The protected schema, tRPC contracts, owner-scoped guardrails, assistant consent gate, and interface compile successfully. Automated tests cover library ownership selection, unselected scan refusal, invite scope, invitation expiry, and AI opt-in enforcement. A successful live scan and real share delivery remain dependent on the owner connecting a reachable Plex or Jellyfin server and selecting their desired source-specific sharing bridge.
