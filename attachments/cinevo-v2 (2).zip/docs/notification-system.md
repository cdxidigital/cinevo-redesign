# CINEVO Notification System

**Author:** Manus AI  
**Status:** Implemented, with external email delivery disabled until the owner supplies provider configuration.

## System overview

CINEVO now uses a unified event model. Every supported event creates an **owner-scoped in-app notification** first. Email is a secondary, optional channel and is attempted only when the owner has enabled email alerts, selected a provider, enabled the relevant event category, and supplied all required server-side environment values.

| Surface | Purpose | Privacy boundary |
|---|---|---|
| In-app notification centre | Displays private library, sharing, and consent events | Protected procedures filter every record by the authenticated user ID |
| Public homepage bell | Available only to an already authenticated owner | The component renders nothing and makes no protected query when signed out |
| Private application bell | Provides unread count and management controls | Lives inside the authenticated `/app` experience |
| Email alerts | Sends concise transactional summaries | Recipient, sender, and provider keys remain server-side |

The notification centre supports an unread badge, Today/Earlier grouping, per-item read and dismiss actions, mark-all-read, clear-all, keyboard dismissal with **Escape**, loading skeletons, and provider preferences. Email messages intentionally exclude media titles, server addresses, access tokens, invitation tokens, and recipient labels.

## Implemented event catalogue

| Event | Category | In-app | Optional email |
|---|---|---:|---:|
| Plex or Jellyfin connected | Library | Yes | Yes |
| Selected libraries updated | Library | Yes | Yes |
| Library scan requested | Library | Yes | Yes |
| Private invitation created | Sharing | Yes | Yes |
| Invitation status changed | Sharing | Yes | Yes |
| AI consent enabled or disabled | Privacy | Yes | Yes |

## Relevant source files

| File | Responsibility |
|---|---|
| `drizzle/schema.ts` | Notification and preference tables |
| `server/db.ts` | Owner-scoped notification persistence |
| `server/notifications.ts` | Event creation, preference evaluation, Resend adapter, and SendGrid adapter |
| `server/routers.ts` | Protected notification procedures and event emission |
| `client/src/components/NotificationCenter.tsx` | Notification-centre interaction and preferences |
| `client/src/components/notification-center.css` | Cinematic notification-centre presentation |
| `client/src/pages/PublicHome.tsx` | Authenticated notification access on the public homepage |
| `client/src/App.tsx` | Notification access in the private application shell |

> The system is **disabled by default for email delivery**. In-app notifications work independently and remain the primary source of truth.

## Validation record

The authenticated CINEVO homepage was reviewed with the notification centre opened from the bell control. The centre renders its private empty state, clear control, settings transition, category toggles, provider selector, and provider-readiness indicators. It is not displayed for signed-out visitors. Email provider indicators correctly report that server keys are still required; no outbound email was sent during implementation validation.

The notification settings panel was also closed through the **Escape** key in the live authenticated interface. The panel’s remaining interactive elements are native buttons, checkboxes, and a select control, preserving standard browser focus order and visible focus treatment.
