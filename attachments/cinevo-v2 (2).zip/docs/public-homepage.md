# CINEVO Public Homepage

The public CINEVO homepage is a **privacy-first entry point**. It explains the product and routes visitors into their private CINEVO account without showing titles, artwork, library metadata, notifications, invitations, AI results, or connections from any user.

The page contains no demo media, sample catalogue, or representative preview content. Its onboarding section describes the live sequence required for an owner to connect Plex or Jellyfin, select private library sections, and bring their own media into CINEVO.

All private operations remain behind the authenticated `/app` boundary. Homepage calls to action invoke the established sign-in flow when necessary and send authenticated owners to their own connection or library-management experience.
