# CINEVO Beta Release Notes

## Included

CINEVO now uses **real private-library states only**. The public site contains no media catalogue, poster rail, sample activity, or imported demonstration content. When an owner has not connected or selected a library, CINEVO explains the next private setup step rather than inventing content.

The interface has been refined for compact mobile screens through desktop, ultrawide, and 4K displays. It now includes a persisted dark/light appearance control, accessible private-library loading skeletons, improved empty and error states, route-level code splitting, and complete root-page Open Graph and Twitter Card metadata using CINEVO-owned artwork.

CINEVO Core provides owner-controlled manual health checks, metadata-refresh readiness, share-safety information, credential-free export preparation, and playback-routing readiness. The notification centre is owner-scoped and supports read, dismiss, clear, and optional email-preference controls. The Node companion remains local-first, with loopback as its default control boundary, short-lived pairing, encrypted provider-token storage, and explicit opt-in LAN access for the Android Controller.

## Beta Expectations

Automated tests validate application contracts and controlled provider responses, not a tester’s live media server, mail provider, operating-system signing chain, or hardware-specific launch path. The accompanying beta checklist identifies the tests that need real authorised environments before a general release.
