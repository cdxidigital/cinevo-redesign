# CINEVO Beta-Test Checklist

## Purpose

This checklist is for private beta testing of CINEVO’s web app and companion tools. CINEVO deliberately has **no demo catalogue**: testers should use their own authorised Plex or Jellyfin server and should never enter credentials, access tokens, or private library paths in a support conversation.

## Web Application

| Area | Tester action | Expected result |
|---|---|---|
| Appearance | Toggle the sun/moon control on the public page, reload, and move into `/app`. | The preference persists and both dark and light appearances retain readable text and visible focus states. |
| Library setup | Connect a reachable Plex or Jellyfin server, then choose individual library sections. | Only selected sections are visible to CINEVO. Cards show a loading state during the request, then a real library, empty state, or actionable error. |
| Search | Search connected items and filter by genre, year, and rating. | Results reflect the private selected-library feed only. |
| Sharing | Create a scoped invitation, copy its private link, check expiry, then revoke it. | The recipient sees only invitation status; the owner can revoke access. |
| CINEVO Core | Review operations, consent, and sharing controls. | Server-health requests and refresh readiness are manual; metadata export never includes credentials or tokens. |
| Notifications | Open the notification centre, mark items read, dismiss an item, clear history, and adjust optional email preferences. | State is owner-scoped. Email remains disabled until a provider, sender, and recipient are configured. |

## Companion Tools

| Package | Tester action | Expected result |
|---|---|---|
| Windows MSI | Install for the current user, launch **CINEVO Node**, review dashboard status, then uninstall. | Start Menu and desktop shortcuts open the branded local control surface. The local dashboard stays loopback-only by default. |
| macOS DMG | Mount the matching Apple Silicon or Intel disk image, drag the app to Applications, then launch it. | The app opens the local Node dashboard. macOS may require an explicit security approval until the release is signed and notarized. |
| Android Controller | Install the APK, enter a trusted home-network address and short pairing code, then check status and selected libraries. | The Controller uses explicit local-network access and does not reveal or persist Plex/Jellyfin credentials. |

## Current Release Boundaries

| Boundary | Beta status | Required before broad distribution |
|---|---|---|
| Real Plex/Jellyfin data | Requires a tester-owned reachable server and credentials entered locally. | Confirm provider-specific playback and selected-library results against each supported server version. |
| Email delivery | Adapter and in-app state are tested without live mail. | Configure a verified Resend or SendGrid sender, recipient, and restricted API key; deliver a monitored test alert. |
| Windows signing | MSI contents and metadata are validated. | Authenticode-sign executable and MSI with an organisation-controlled certificate. |
| macOS signing | Disk-image payloads are validated. | Sign, notarize, staple, and test on physical Apple Silicon and Intel hardware. |
| Android release signing | Debug and unsigned release APK builds are validated. | Sign with an organisation-controlled keystore, test Android installation, then prepare an AAB for Play distribution if required. |

## Release Gate

Do not promote this build beyond private beta until the relevant connected-server, signed-installer, and live-email checks above have been completed and recorded by an authorised owner.
