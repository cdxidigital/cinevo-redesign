# CINEVO Product Boundaries

## Real-library-only media

CINEVO no longer includes representative titles, sample artwork, or mock browsing data. Movies, series, artwork, metadata, watch progress, favourites, genre filters, search results, and similarity suggestions appear only when the authenticated owner connects a private Plex or Jellyfin library and selects sections for CINEVO to index.

When no private library is connected or selected, CINEVO presents connection, discovery, and empty states rather than fabricated catalogue content. CINEVO does not host, import, publish, or infer customer media.

## Private platform controls

All Plex and Jellyfin credentials remain on the server-side connection boundary. Library selection, scan requests, invite-only sharing, stewardship activity, and consent-led metadata assistance are owner-controlled. Friends receive scoped, expiring, revocable invitations; no library is publicly listed or discoverable.

## Playback boundary

CINEVO exposes a cinematic control interface for items returned by an authorised private library. Actual playback routing must be enabled through the owner’s chosen Plex or Jellyfin environment before media can start. This limitation is stated in the control surface and does not use substitute media.

## Design governance

The interface uses a near-black foundation, white typography, Montserrat display hierarchy, DM Sans interface text, and electric cyan-to-violet action accents. Translucent treatment is restricted to the top navigation, search, modal, and player-control overlays. Content surfaces remain direct and spare to preserve the private-cinema tone.

## Validation record

The public and private connection states have been reviewed across desktop and compact mobile dimensions. The application includes explicit loading, empty, error, and recovery states for private-library data. Type checks and the automated suite cover connection parsing, provider normalisation, selected-library filtering, sharing permissions, AI consent, notifications, and owner-scoped delivery behaviour.
