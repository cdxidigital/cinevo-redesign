# CINEVO Reference Analysis

The provided reference presents CINEVO as a cinematic media product with a translucent dark top navigation, a broad high-contrast hero, neon cyan-to-violet primary gradients, and rounded dark panels. Its desktop home surface exposes Home, Movies, Series, My Library, and AI Picks; the left wordmark includes the “Cinema, Reinvented” descriptor, while the right side uses compact search, notification, settings, and profile controls.

The observed hero uses a prominent “Now streaming” status badge, an editorial “Top Rated” badge, oversized white feature typography, clear primary/secondary calls to action, and concise technical metadata such as year, runtime, genres, 4K, and HDR. The home page continues into distinct collections, category cards, product capability cards, and a closing statement. This supports a more structured content-and-platform narrative than the current CINEVO v2 browse-only landing surface.

The My Library navigation is gated behind the reference application’s sign-in route. Its visible sign-in screen uses a restrained, centered dark card on a violet-to-black ambient gradient with minimal fields and a bright gradient submit action. The reference therefore supports maintaining CINEVO’s existing secure account and private-library gate rather than presenting source credentials or library data publicly.

The reference’s `/movies` navigation target returned a 404 during review, so its browse-page structure cannot be treated as a reliable implementation source. CINEVO will preserve its existing, functional Movies and Series views while adopting the confirmed visual principles from the reference home surface: disciplined dark hierarchy, clear status badges, gradient emphasis for primary intent, structured platform narrative, and compact utility controls.

## Translation Decisions

| Reference pattern | CINEVO v2 translation |
|---|---|
| High-contrast editorial hero | Retain real selected-library artwork when connected; otherwise use an owner-safe private-library gate. |
| Cyan-to-violet gradient action system | Introduce a signature gradient only for primary action and status surfaces while retaining electric violet as CINEVO’s principal accent. |
| Five-part product navigation | Preserve the user-mandated Home, Movies, Series, and My List labels; position My Library and AI Picks as CINEVO Core destinations rather than displacing those fixed labels. |
| My Library account gate | Keep existing authenticated, server-side Plex/Jellyfin workflows and the private-library boundary. |
| Product capability cards | Translate into CINEVO Core’s transparent library, friend-sharing, stewardship, and consent-led AI controls. |

The reference is a visual and interaction reference only. Its exact copy, media metadata, and any public-content positioning will not be copied into CINEVO.

## Rebuild Review

The rebuilt unauthenticated gateway has been checked at desktop and mobile sizes. It now carries the reference’s centered editorial composition, restrained dark gradient atmosphere, cyan-to-violet primary action emphasis, and decisive private-media value proposition while retaining the original CINEVO privacy copy and secure Plex/Jellyfin paths. The authenticated library, Core, share-link, and AI-scope surfaces compile and are covered by the test suite; their final live visual review requires a connected owner server because CINEVO does not fabricate a personal-library session for preview.
