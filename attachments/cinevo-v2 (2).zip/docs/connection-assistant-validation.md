# CINEVO Connection Assistant Validation

## Completed checks

The simplified library gateway was reviewed at desktop and mobile widths. The dual-source choice remains immediately visible, with **Connect Plex** presented as the primary option and **Connect Jellyfin** retained as a secondary option. At the mobile viewport, the actions stack with comfortable touch spacing and the privacy reminder remains legible.

The Plex assistant opens into a single-link quick-connect step, exposes a short explanation of how CINEVO protects the token, provides an expandable Plex help path, and retains a manual address-plus-token fallback. The client helper was covered with tests for token extraction, server-root derivation, automatic HTTPS normalization, tokenless links, insecure addresses, and matching Jellyfin address validation.

The manual recovery action was also exercised in the live preview. It expands the secure server-address and access-token fields without dismissing the quick-connect input, allowing the user to switch paths without re-entering a modal or losing their explanatory context.

### Mobile recovery review

At the compact mobile layout, the guided Plex modal keeps its quick-connect field, error slot, help disclosure, and manual fallback in a single vertical reading order. The parser rejects insecure or tokenless links with a visible in-context error rather than resetting the form. The manual fallback remains available without losing the pasted link, while the CINEVO Settings source-management row retains a **Reconnect** control for an existing Plex connection. Focused tests verify secure-link rejection, error-slot presence, manual fallback copy, and the reconnect control; the responsive layout was previously reviewed at the compact viewport.

## Remaining owner validation

A successful end-to-end connection requires the owner’s real, publicly reachable HTTPS Plex Media Server and a valid Plex access token. CINEVO does not request either value in chat. Enter the complete Plex connection link in the in-app assistant to validate the final connection, real library artwork, and imported browsing data.
